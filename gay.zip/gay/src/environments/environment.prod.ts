export const environment = {
  production: true,
  url_api: 'https://api.nossoerp.com.br',
  url_api_zap: 'https://obtersolucoes.nossoerp.com.br/api/whatsapp/go',
  firebaseConfig: {
    apiKey: 'AIzaSyAiGcjnLeJ1_hAElEeukV4JOS7SKOQgub8',
    authDomain: 'nossoerp-obtersolucoes.firebaseapp.com',
    databaseURL: 'https://nossoerp-obtersolucoes.firebaseio.com',
    projectId: 'nossoerp-obtersolucoes',
    storageBucket: 'nossoerp-obtersolucoes.appspot.com',
    messagingSenderId: '856195612154',
    appId: '1:856195612154:web:2524849436ac342443f843',
    measurementId: 'G-1H0R930LRR',
  },
};
