// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  //url_api: 'https://api.nossoerp.com.br',
  url_api: 'https://localhost:7273',
  url_api_zap: 'https://obtersolucoes.nossoerp.com.br/api/whatsapp/go',
  firebaseConfig: {
    apiKey: 'AIzaSyAiGcjnLeJ1_hAElEeukV4JOS7SKOQgub8',
    authDomain: 'nossoerp-obtersolucoes.firebaseapp.com',
    databaseURL: 'https://nossoerp-obtersolucoes.firebaseio.com',
    projectId: 'nossoerp-obtersolucoes',
    storageBucket: 'nossoerp-obtersolucoes.appspot.com',
    messagingSenderId: '856195612154',
    appId: '1:856195612154:web:2524849436ac342443f843',
    measurementId: 'G-1H0R930LRR',
  },
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
