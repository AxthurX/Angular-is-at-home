import { Util } from './../../../nosso-dr/core/util.model';
import {
  Component,
  OnInit,
  HostListener,
  ViewChild,
  ElementRef,
} from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { MENU } from './menu';
import { MenuItem } from './menu.model';
import { AuthService, LoginResponse } from 'src/app/nosso-dr/core/services/auth.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ClasseBase } from 'src/app/nosso-dr/core/model/classe-base.model';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss'],
})
export class NavbarComponent extends ClasseBase implements OnInit {
  @ViewChild('modal', { static: true }) modal: ElementRef;
  resposta: LoginResponse;
  menuItems: MenuItem[] = [];
  colaborador = this.auth.getColaboradorLogado();
  medico_selecionado = this.auth.getMedicoSelecionado();
  atendente_selecionado = this.auth.getAtendenteSelecionado();
  /**
   * Fixed header menu on scroll
   */
  @HostListener('window:scroll', ['$event']) getScrollHeight() {
    if (window.matchMedia('(min-width: 992px)').matches) {
      let header: HTMLElement = document.querySelector(
        '.horizontal-menu'
      ) as HTMLElement;
      if (window.pageYOffset >= 60) {
        header.parentElement!.classList.add('fixed-on-scroll');
      } else {
        header.parentElement!.classList.remove('fixed-on-scroll');
      }
    }
  }

  constructor(
    private router: Router,
    private auth: AuthService,
    private modalSrv: NgbModal
  ) {
    super();
  }

  ngOnInit(): void {
    this.menuItems = MENU;
    /**
     * closing the header menu after route change in tablet/mobile devices
     */
    if (window.matchMedia('(max-width: 991px)').matches) {
      this.router.events.forEach((event) => {
        if (event instanceof NavigationEnd) {
          document
            .querySelector('.horizontal-menu .bottom-navbar')!
            .classList.remove('header-toggled');
        }
      });
    }
  }

  /**
   * Returns true or false if given menu item has child or not
   * @param item menuItem
   */
  hasItems(item: MenuItem) {
    return item.subMenus !== undefined ? item.subMenus.length > 0 : false;
  }

  /**
   * Logout
   */
  onLogout(e: Event) {
    e.preventDefault();
    Util.Confirm('Sair da aplicação').then((value) => {
      if (value.isConfirmed) {
        this.auth.logout();
      }
    });
  }

  /**
   * Toggle header menu in tablet/mobile devices
   */
  toggleHeaderMenu() {
    document
      .querySelector('.horizontal-menu .bottom-navbar')!
      .classList.toggle('header-toggled');
  }

  trocarMedico(e: Event) {
    try {
      this.carregando = true;
      e.preventDefault();
      this.resposta = this.auth.getLogin();

      if (this.resposta.authenticated && this.atendente_selecionado.todos == true) {
        this.modalSrv
          .open(this.modal, { size: 'lg', centered: true })
          .result.then((result) => {
            if (result) {
              this.auth.setToken(
                this.resposta.token,
                this.resposta.dados_colaborador,
                this.resposta.dados_empresa,
                result,
                this.resposta.atendente
              );
              setTimeout(() => {
                this.router.navigate(['/agenda']);
                Util.Notificacao(
                  'Troca de usuário realizada com sucesso!',
                  'success'
                );
              }, 100);
              window.location.reload();
            }
            this.carregando = false;
          })
          .catch((res) => {
            if (res === 0) {
              return;
            }
            this.TratarErro(res);
          });
      } else {
        Util.AlertWarning('Você não tem a permissão para gerenciar a agenda de outros médicos!');
      }
    } catch (e) {
      this.TratarErro(e);
    }
  }

  trocarUsuario(e: Event) {
    try {
      this.carregando = true;
      e.preventDefault();
      this.resposta = this.auth.getLogin();
      if (this.resposta.authenticated && this.atendente_selecionado.todos == true) {
        this.modalSrv
          .open(this.modal, { size: 'lg', centered: true })
          .result.then((result) => {
            if (result) {
              this.auth.setToken(
                this.resposta.token,
                this.resposta.dados_colaborador,
                this.resposta.dados_empresa,
                result,
                this.resposta.atendente
              );
              setTimeout(() => {
                this.router.navigate(['/agenda']);
                Util.Notificacao(
                  'Troca de usuário realizada com sucesso!',
                  'success'
                );
              }, 100);
              window.location.reload();
            }
            this.carregando = false;
          })
          .catch((res) => {
            if (res === 0) {
              return;
            }
            this.TratarErro(res);
          });
      } else {
        Util.AlertWarning('Você não tem a permissão para gerenciar a agenda de outros médicos!');
      }
    } catch (e) {
      this.TratarErro(e);
    }
  }
}
