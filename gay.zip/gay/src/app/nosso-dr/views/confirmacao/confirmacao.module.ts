import { ReactiveFormsModule } from "@angular/forms";
import { NgSelectModule } from "@ng-select/ng-select";
import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { SharedModule } from "../../core/shared.module";
import { RouterModule, Routes } from "@angular/router";
import { ConfirmacaoComponent } from "./confirmacao.component";

const routes: Routes = [
  {
    path: "",
    component: ConfirmacaoComponent,
  },
];

@NgModule({
  declarations: [ConfirmacaoComponent],
  imports: [
    CommonModule,
    SharedModule,
    NgSelectModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes)
  ],
})
export class ConfirmacaoModule {}
