import { Component, OnChanges, OnInit } from "@angular/core";
import { AuthService, Medico } from "../../core/services/auth.service";
import { Util } from "../../core/util.model";
import { ActivatedRoute } from "@angular/router";
import { formatDate } from "@angular/common";
import { AgendamentoService } from "../../core/services/agendamento.service";
@Component({
  selector: "app-confirmacao",
  templateUrl: "./confirmacao.component.html",
  styleUrls: ["./confirmacao.component.scss"],
})
export class ConfirmacaoComponent implements OnInit, OnChanges {
  medico_selecionado: Medico = this.auth.getMedicoSelecionado();
  data = new Date();
  data_passou: boolean;
  agendamento: any;
  cod: string;
  constructor(
    private agendamentoSrv: AgendamentoService,
    private auth: AuthService,
    private route: ActivatedRoute
  ) {
    this.data_passou = false;
  }

  ngOnInit(): void {
    try {
      this.route.params.subscribe((params) => {
        this.cod = params["cod"];
      });
      this.detalhesAgendamento();
    } catch (e) {
      Util.TratarErro(e);
    }
  }

  ngOnChanges() {
    try {
      this.detalhesAgendamento();
    } catch (e) {
      Util.TratarErro(e);
    }
  }

  getSiglaConselho() {
    return "Sigla do conselho";
  }

  confirmarAtendimento() {
    try {
      this.agendamentoSrv.confirmarAgendamento(this.cod).subscribe({
        next: (r) => {
          if (r.success) {
            Util.AlertSucess("Atendimento confirmado com sucesso");
          } else {
            Util.TratarErro(r.message);
          }
        },
      });
    } catch (e) {
      Util.TratarErro(e);
    }
  }

  detalhesAgendamento() {
    try {
      const formatdate = formatDate(this.data, "yyyy/MM/ddTHH:mm:ss", "pt-BR");
      const datenow = formatdate.split("/").join("-");
      this.agendamentoSrv.detalheAgendamento(this.cod).subscribe({
        next: (r) => {
          if (r.success) {
            this.agendamento = r.retorno;
            if (datenow.toString() > this.agendamento?.data_final) {
              this.data_passou = true;
            }
          }
        },
      });
    } catch (e) {
      Util.TratarErro(e);
    }
  }
}
