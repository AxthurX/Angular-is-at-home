import { Component, ElementRef, OnChanges, OnInit, ViewChild } from "@angular/core";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { ClasseBase } from "../../core/model/classe-base.model";
import { AuthService, DadosEmpresa, Medico } from "../../core/services/auth.service";
import { WhatsAppService } from "../../core/services/whats-app.service";
import { Util } from "../../core/util.model";
import { ClienteService } from "../../core/services/cliente.service";
import { UF } from "../cadastros/cliente/cliente.model";
import { UsuarioService } from "../../core/services/usuario.service";
import { Conselho, Email } from "./configuracao.model";

@Component({
  selector: "app-configuracao",
  templateUrl: "./configuracao.component.html",
  styleUrls: ["./configuracao.component.scss"],
})
export class ConfiguracaoComponent extends ClasseBase implements OnInit, OnChanges {
  @ViewChild("modalTeste", { static: true }) modalPrincipal: ElementRef;
  telefone_teste: string = "69";
  email = new Email();
  conselho = new Conselho();
  habilitado: boolean;
  processando: boolean;
  qrCodebase64: string;
  consultando: boolean;
  dados_empresa: DadosEmpresa;
  medico_selecioando: Medico;
  ufs: UF[] = [];
  constructor(
    private usuarioSrv: UsuarioService,
    private utilSrv: ClienteService,
    private srv: WhatsAppService,
    private modal: NgbModal,
    private auth: AuthService
  ) {
    super();
    this.dados_empresa = auth.getEmpresaLogada();
    this.medico_selecioando = auth.getMedicoSelecionado();
    this.habilitado = this.dados_empresa.habilitar_integracao_whatsapp_nosso_dr;
    this.conselho.sigla_conselho = this.medico_selecioando.sigla_conselho;
    this.conselho.id_uf_conselho = this.medico_selecioando.id_uf_conselho;
    this.conselho.numero_conselho = this.medico_selecioando.numero_conselho;
    this.conselho.rqe = this.medico_selecioando.rqe;
    this.email.endereco_email = this.medico_selecioando.endereco_email;
    this.email.senha_email = this.medico_selecioando.senha_email;
    this.email.exibicao_email = this.medico_selecioando.exibicao_email;
    this.email.email_copia_oculta =
      this.medico_selecioando.email_copia_oculta;
    this.email.ssl = this.medico_selecioando.ssl;
    this.email.assinatura = this.medico_selecioando.assinatura;
    this.email.smtp = this.medico_selecioando.smtp;
    this.email.porta = this.medico_selecioando.porta;
  }

  onMudouHabilitacao() {
    try {
      if (
        this.habilitado !=
        this.dados_empresa.habilitar_integracao_whatsapp_nosso_dr
      ) {
        this.usuarioSrv
          .atualizarHabilitacaoWhatsAppMedico(this.habilitado)
          .subscribe({
            next: (retorno) => {
              if (retorno.success) {
                this.dados_empresa.habilitar_integracao_whatsapp_nosso_dr =
                  this.habilitado;
                this.auth.setDadosEmpresa(this.dados_empresa);
              } else {
                this.habilitado = !this.habilitado;
                this.TratarErro(retorno.message);
              }
            },
            error: (e) => {
              this.habilitado = !this.habilitado;
              this.TratarErro(e);
            },
          });
      }
    } catch (e) {
      this.TratarErro(e);
    }
  }

  ngOnInit(): void {
    try {
      this.consultando = true;
      this.utilSrv.getUf().subscribe((ufs) => {
        this.ufs = ufs.retorno;
        this.consultando = false;
      });
    } catch (e) {
      Util.TratarErro(e);
      this.consultando = false;
    }
  }

  ngOnChanges(): void {
    try {
      this.auth.getEmpresaLogada();
      this.auth.getMedicoSelecionado();
    } catch (e) {
      this.TratarErro(e);
    }
  }

  override getTitulo(): string {
    return "Configure o whats app que irá utilizar para notificar os clientes";
  }

  gerarQrCode() {
    try {
      this.carregando = true;
      this.qrCodebase64 = "";
      //primeiro iniciou a instancia, n importa se ja tiver iniciada, vai da sucesso do msm jeito
      this.srv.iniciarInstancia().subscribe({
        next: (retorno) => {
          if (!retorno.error) {
            //depois de iniciar, tento gerar o qr code
            //dou uma pausa pra evitar vim vazio
            setTimeout(() => {
              this.srv.gerarQrCode().subscribe({
                next: (retQrCode) => {
                  if (!retQrCode.error) {
                    this.qrCodebase64 = retQrCode.qrcode;
                    if (this.qrCodebase64) {
                      Util.NotificacaoSucesso("QR-Code gerado com sucesso!");
                    } else {
                      Util.AlertInfo(
                        "Não foi possível gerar um novo qr-code, por favor verifique se o aparelho já esta conectado com o whats. Desconecte caso for necessário!"
                      );
                    }
                  } else {
                    this.TratarErro(retQrCode.message);
                  }
                  this.carregando = false;
                },
                error: (e) => {
                  this.TratarErro(e);
                },
              });
            }, 2000);
          } else {
            this.TratarErro(retorno.message);
          }
        },
        error: (e) => {
          this.TratarErro(e);
        },
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  abrirTeste() {
    try {
      this.modal.open(this.modalPrincipal, { size: "sm", centered: true });
      setTimeout(() => {
        document.getElementById("txtTeste")?.focus();
      }, 500);
    } catch (e) {
      this.TratarErro(e);
    }
  }

  testar() {
    try {
      if (
        this.telefone_teste?.length === 10 ||
        this.telefone_teste?.length === 11
      ) {
        this.processando = true;
        this.srv
          .enviarMensagem(
            this.telefone_teste,
            "_Olá_, está uma *mensagem de teste* de integração do ```Nosso DR``` com o whatsapp! ~Não responder!~"
          )
          .subscribe({
            next: (retorno) => {
              if (!retorno.error) {
                Util.AlertSucess("Mensagem enviada com sucesso!");
              } else {
                this.TratarErro(retorno.message);
              }
              this.processando = false;
            },
            error: (e) => {
              this.processando = false;
              this.TratarErro(e);
            },
          });
      } else {
        Util.AlertWarning("Preencha o número corretamente!");
      }
    } catch (e) {
      this.TratarErro(e);
    }
  }

  salvarConfiguracaoConselho() {
    try {
      if (this.conselho.id_uf_conselho && this.conselho.sigla_conselho && this.conselho.rqe) {
        this.conselho.id_medico = this.auth.getMedicoSelecionado().id_usuario;
        this.conselho.sigla_conselho.toUpperCase();
        this.usuarioSrv.atualizarInformacaoConselho(this.conselho).subscribe({
          next: (retorno) => {
            if (retorno.success) {
              this.medico_selecioando.sigla_conselho =
                this.conselho.sigla_conselho;
              this.medico_selecioando.id_uf_conselho =
                this.conselho.id_uf_conselho;
              this.medico_selecioando.numero_conselho =
                this.conselho.numero_conselho;
              this.medico_selecioando.rqe = this.conselho.rqe;
              this.auth.setDadosMedico(this.medico_selecioando);
              Util.AlertSucess("Informações do conselho salvas com sucesso");
              this.ngOnChanges();
            } else {
              this.TratarErro(retorno.message);
            }
          },
          error: (e) => {
            this.TratarErro(e);
          },
        });
      } else {
        Util.AlertWarning("Preencha os campos para salvar");
      }
    } catch (e) {
      this.TratarErro(e);
    }
  }

  salvarConfiguracaoEmail() {
    try {
      if (this.email.endereco_email && this.email.senha_email && this.email.porta) {
        this.email.id_medico = this.auth.getMedicoSelecionado().id_usuario;
        this.usuarioSrv.atualizarInformacaoEmail(this.email).subscribe({
          next: (retorno) => {
            if (retorno.success) {
              this.medico_selecioando.endereco_email =
                this.email.endereco_email;
              this.medico_selecioando.senha_email = this.email.senha_email;
              this.medico_selecioando.exibicao_email =
                this.email.exibicao_email;
              this.medico_selecioando.email_copia_oculta =
                this.email.email_copia_oculta;
              this.medico_selecioando.ssl = this.email.ssl;
              this.medico_selecioando.assinatura = this.email.assinatura;
              this.medico_selecioando.smtp = this.email.smtp;
              this.medico_selecioando.porta = this.email.porta;
              this.auth.setDadosMedico(this.medico_selecioando);
              Util.AlertSucess("Informações do email salvas com sucesso");
              this.ngOnChanges();
            } else {
              this.TratarErro(retorno.message);
              Util.AlertWarning("Verifique se o email esta configurado!");
            }
          },
          error: (e) => {
            this.TratarErro(e);
          },
        });
      } else {
        Util.AlertWarning("Preencha os campos para salvar");
      }
    } catch (e) {
      this.TratarErro(e);
    }
  }
}
