import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { SharedModule } from "src/app/nosso-dr/core/shared.module";
import { NgbActiveModal } from "@ng-bootstrap/ng-bootstrap";
import { ReactiveFormsModule } from "@angular/forms";
import { ConfiguracaoComponent } from "./configuracao.component";
import { ArchwizardModule } from "angular-archwizard";
import { NgxMaskModule } from "ngx-mask";
import { NgSelectModule } from "@ng-select/ng-select";

const routes: Routes = [
  {
    path: "",
    component: ConfiguracaoComponent,
  },
];

@NgModule({
  declarations: [ConfiguracaoComponent],
  imports: [
    SharedModule,
    NgSelectModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes),
    ArchwizardModule,
    NgxMaskModule.forRoot({ validation: true }), // Ngx-mask
  ],
  providers: [NgbActiveModal],
})
export class ConfiguracaoModule {}
