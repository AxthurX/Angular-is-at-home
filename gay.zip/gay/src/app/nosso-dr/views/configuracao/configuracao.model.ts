export class Email {
  id_medico: number;
  endereco_email: string;
  senha_email: string;
  exibicao_email: string;
  email_copia_oculta: string;
  assinatura: string;
  smtp: string;
  porta: string;
  ssl: boolean = false;
}

export class Conselho {
  id_medico: number;
  sigla_conselho: string;
  id_uf_conselho: number;
  numero_conselho: string;
  rqe: string;
}
