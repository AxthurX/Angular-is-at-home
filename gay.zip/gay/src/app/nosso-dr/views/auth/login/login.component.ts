import { Component, ElementRef, OnInit, ViewChild } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { ClasseBase } from "src/app/nosso-dr/core/model/classe-base.model";
import { AuthService, LoginResponse } from "src/app/nosso-dr/core/services/auth.service";
import { Util } from "src/app/nosso-dr/core/util.model";

@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.scss"],
})
export class LoginComponent extends ClasseBase implements OnInit {
  @ViewChild("modal", { static: true }) modal: ElementRef;
  returnUrl: any;
  login: string = "";
  senha: string = "";
  resposta: LoginResponse;
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private auth: AuthService,
  ) {
    super();
  }

  ngOnInit(): void {
    // get return url from route parameters or default to '/'
    this.returnUrl = this.route.snapshot.queryParams["returnUrl"] || "/";
  }

  onLogar(e: Event) {
    try {
      this.carregando = true;
      e.preventDefault();

      this.auth.getUsuario(this.login, this.senha).subscribe(
        (r) => {
          this.resposta = r;
          this.auth.setLogin(this.resposta);
          if (this.resposta.authenticated) {
            if (this.resposta.dados_colaborador.tipo_usuario_nosso_dr === 1) {
              const medico = this.resposta.medicos[0];
              this.auth.setToken(
                this.resposta.token,
                this.resposta.dados_colaborador,
                this.resposta.dados_empresa,
                medico,
                this.resposta.atendente
              );
              this.router.navigate([this.returnUrl]);
              Util.Notificacao(
                `Login realizado com sucesso para o médico ${medico.nome}`,
                `success`
              );
            } else {
              const medico = this.resposta.medicos[0];
              this.auth.setToken(
                this.resposta.token,
                this.resposta.dados_colaborador,
                this.resposta.dados_empresa,
                medico,
                this.resposta.atendente
              );
              this.router.navigate([this.returnUrl]);
              Util.Notificacao(
                `Login realizado com sucesso para o atendente ${this.resposta.atendente.nome} e para o médico ${medico.nome}`,
                `success`
              );
            }
            this.carregando = false;
            setTimeout(() => {
              Util.NotificacaoConfiguracao(
                `É necessário configurar as informações do médico na aba de configurações para garantir a correta emissão de documentos.`,
                `info`
              );
            }, 2000);
          } else {
            this.Warning(r.message);
          }
        },
        (e) => {
          this.TratarErro(e);
        }
      );
    } catch (e) {
      this.TratarErro(e);
    }
  }
}
