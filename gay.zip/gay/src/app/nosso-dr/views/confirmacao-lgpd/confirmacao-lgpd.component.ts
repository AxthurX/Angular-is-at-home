import { Component, OnInit } from '@angular/core';
import { Util } from '../../core/util.model';
import { AuthService, DadosEmpresa } from '../../core/services/auth.service';
import { ActivatedRoute } from '@angular/router';
import { TermoConsentimentoComponent } from '../../core/components/termo-consentimento.component';
import { FirebaseService } from '../../core/services/firebase.service';
import { ProntuarioService } from '../../core/services/prontuario.service';
import { ClasseBase } from '../../core/model/classe-base.model';

@Component({
  selector: 'app-confirmacao-lgpd',
  templateUrl: './confirmacao-lgpd.component.html',
  styleUrls: ['./confirmacao-lgpd.component.scss'],
})
export class ConfirmacaoLgpdComponent extends ClasseBase implements OnInit {
  dados_empresa: DadosEmpresa = this.auth.getEmpresaLogada();
  termo_consentimento: boolean;
  detalhes_termo: any;
  consultando: boolean;
  base64: string;
  cod: string;
  dia: number;
  mes: string;
  ano: number;

  constructor(
    private prontuarioSrv: ProntuarioService,
    private auth: AuthService,
    private route: ActivatedRoute,
    private firebaseSrv: FirebaseService
  ) {
    super();
  }

  ngOnInit(): void {
    try {
      this.route.params.subscribe((params) => {
        this.cod = params["cod"];
      });
      this.detalhesTermoLgpd();
      const data = new Date();
      this.dia = data.getDate();
      this.mes = data.toLocaleString("pt-br", { month: "long" });
      this.ano = data.getFullYear();
    } catch (e) {
      Util.TratarErro(e);
    }
  }

  confirmarTermoLgpd() {
    try {
      this.prontuarioSrv.confirmarTermoLgpd(this.cod).subscribe({
        next: (r) => {
          if (r.success) {
            Util.AlertSucess("Termo de Consentimento aceito com sucesso.");
            this.detalhesTermoLgpd();
          } else {
            Util.TratarErro(r.message);
          }
        },
      });
    } catch (e) {
      Util.TratarErro(e);
    }
  }

  detalhesTermoLgpd() {
    try {
      this.prontuarioSrv.detalheTermoLgpd(this.cod).subscribe({
        next: (r) => {
          if (r.success) {
            this.detalhes_termo = r.retorno;
          }
        },
      });
    } catch (e) {
      Util.TratarErro(e);
    }
  }

  imprimirTermo() {
    try {
      let content = TermoConsentimentoComponent.termo();
      content = content.replace(/\{{nome_paciente}}/g, this.detalhes_termo.paciente);
      content = content.replace(/\{{nome_clinica}}/g, this.auth.getEmpresaLogada().nome_colaborador);
      content = content.replace(/\{{cpf_paciente}}/g, this.detalhes_termo.cpf_cnpj);
      content = content.replace(/\{{dia}}/g, this.dia.toString());
      content = content.replace(/\{{mes}}/g, this.mes);
      content = content.replace(/\{{ano}}/g, this.ano.toString());
      content = content.replace(/\{{municipio}}/g, "Porto velho");
      content = content.replace(/\{{uf}}/g, "RO");
      const id = this.firebaseSrv.createId();
      const url = "https://obtersolucoes.nossoerp.com.br/nossoerpnuvem?id=" + id;

      if (content) {
        this.firebaseSrv.setHtmlImpressao(id, content).then(
          () => {
            this.consultando = false;
            window.open(
              url,
              "_blank",
              "toolbar=no,scrollbars=no,resizable=no,width=900,height=1000"
            );
          },
          (e) => {
            Util.TratarErro(e);
            this.limparDadosGerando();
            this.consultando = false;
          }
        );
      }
    } catch (e) {
      Util.TratarErro(e);
      this.limparDadosGerando();
      this.consultando = false;
    }
  }

  limparDadosGerando() {
    this.consultando = false;
    this.base64 = "";
  }
}
