import { ReactiveFormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { NgModule } from '@angular/core';
import { SharedModule } from '../../core/shared.module';
import { RouterModule, Routes } from '@angular/router';
import { ConfirmacaoLgpdComponent } from './confirmacao-lgpd.component';

const routes: Routes = [
  {
    path: '',
    component: ConfirmacaoLgpdComponent,
  },
];

@NgModule({
  declarations: [ConfirmacaoLgpdComponent],
  imports: [
    SharedModule,
    NgSelectModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes),
  ],
})
export class ConfirmacaoLgpdModule {}
