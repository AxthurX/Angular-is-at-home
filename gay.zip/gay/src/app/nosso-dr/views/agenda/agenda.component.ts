import { Component, OnInit, ViewChild, ElementRef, OnChanges } from '@angular/core';
import {
  CalendarOptions,
  DateSelectArg,
  EventClickArg,
  EventApi,
  DatesSetArg,
  FullCalendarComponent,
  EventChangeArg,
} from '@fullcalendar/angular';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import esLocale from '@fullcalendar/core/locales/pt-br';
import { Agendamento } from './agendamento.model';
import { AuthService } from '../../core/services/auth.service';
import { Util } from '../../core/util.model';
import { ClasseBase } from '../../core/model/classe-base.model';
import { TipoIcone } from '../../core/components/icone.component';
import { ClienteLookup } from '../cadastros/cliente/cliente-lookup.model';
import { LookupModel } from '../../core/components/lookup.component';
import { WhatsAppService } from '../../core/services/whats-app.service';
import { AgendamentoService } from '../../core/services/agendamento.service';

@Component({
  selector: 'app-agenda',
  templateUrl: './agenda.component.html',
  styleUrls: ['./agenda.component.scss'],
})
export class AgendaComponent extends ClasseBase implements OnInit, OnChanges {
  @ViewChild('calendario') calendarComponent: FullCalendarComponent;
  @ViewChild('externalEvents', { static: true }) externalEvents: ElementRef;
  @ViewChild('modalPrincipal', { static: true }) modalPrincipal: ElementRef;
  @ViewChild('modalTriagem', { static: true }) modalTriagem: ElementRef;
  @ViewChild('modalOpcoes', { static: true }) modalOpcoes: ElementRef;
  @ViewChild('modalCancelados', { static: true }) modalCancelados: ElementRef;
  @ViewChild('modalNaoConfirmados', { static: true }) modalNaoConfirmados: ElementRef;

  lookup_cliente: ClienteLookup;
  agendamento: Agendamento;
  agendamentos: Agendamento[] = [];
  agendamentos_cancelados: Agendamento[] = [];
  agendamentos_naoconfirmados: Agendamento[] = [];
  opcoes_status = Util.GetStatusAgendamento();
  tipos_agendamentos = Util.GetTiposAgendamentos();
  medicos = this.auth.getLogin().medicos;
  colaborador = this.auth.getColaboradorLogado();
  medico = this.auth.getMedicoSelecionado();

  calendarOptions: CalendarOptions = {
    headerToolbar: {
      left: 'prev,today,next',
      center: 'title',
      right: 'timeGridWeek,dayGridMonth,timeGridDay,listWeek',
    },
    initialView: 'timeGridWeek',
    weekends: true,
    editable: true,
    selectable: true,
    selectMirror: true,
    dayMaxEvents: true,
    locale: 'pt-BR',
    locales: [esLocale],
    datesSet: this.onMudouPeriodo.bind(this),
    select: this.novoAgendamento.bind(this),
    eventClick: this.onClicou.bind(this),
    eventChange: this.onChange.bind(this),
    /* you can update a remote database when these fire:
    eventAdd:
    eventChange:
    eventRemove:
    */
  };
  currentEvents: EventApi[] = [];
  data_inicial: Date;
  data_final: Date;
  replace: string;
  novo_id: string;
  constructor(
    private modalService: NgbModal,
    private agendamentoSrv: AgendamentoService,
    public auth: AuthService,
    private whatsSrv: WhatsAppService
  ) {
    super();
    this.lookup_cliente = new ClienteLookup();
  }

  ngOnInit(): void {}

  ngOnChanges() {
    try {
      this.consultarAgendamentos();
    } catch (e) {
      Util.TratarErro(e);
    }
  }

  setFocusDocumento() {
    try {
      setTimeout(() => {
        document.getElementById('temperatura')?.focus();
      }, 500);
    } catch (e) {
      console.error('setFocusDocumento', e);
    }
  }

  getIcone(status: number): TipoIcone | undefined {
    return Util.GetIconeAgendamento(status);
  }

  openModalAgendamento() {
    setTimeout(() => {
      document.getElementById('horario_fim')?.focus();
    }, 500);
    this.modalService.dismissAll();
    this.modalService.open(this.modalPrincipal, { size: 'xl', centered: true });
  }

  openModalTriagem() {
    this.setFocusDocumento();
    this.modalService.dismissAll();
    this.modalService.open(this.modalTriagem, { size: 'sm', centered: true });
  }

  solicitarConfirmacaoCliente(numero: string, agendamento: Agendamento) {
    try {
      this.carregando = true;
      let id_agendamento = agendamento?.id;
      let id_aleatorio = Math.floor(Math.random() * (5000 - 100 + 1)) + 100;
      let id_soma = id_aleatorio + id_agendamento;
      this.replace = [id_aleatorio.toString(), id_agendamento.toString(),id_soma.toString()].join('-');
      this.novo_id = "abc12345#$*%".replace(/([^\d]*)(\d*)([^\w]*)/, this.replace);

      this.whatsSrv
        .enviarMensagem(
          numero,
          `Gostaria de confirmar o horário de sua consulta com Dr(a) ${agendamento?.agendado_por.trim()}, agendada para ${
            agendamento?.agendado_para}? Acesse o Link abaixo e confirme: http://localhost:4200/confirmacao/${this.novo_id}`
        )
        .subscribe({
          next: (r) => {
            this.carregando = false;
            if (!r.error) {
              Util.AlertSucess(
                'Solicitação de mensagem enviada com sucesso! Confirme no aparelho se realmente a mensagem foi entregue ao paciente!'
              );
            } else if (r.error) {
              Util.AlertWarning(
                'Verifique se você habilitou a integração com o whats app'
              );
            } else {
              this.TratarErro(r.message);
            }
          },
          error: (e) => this.TratarErro(e),
        });
    } catch (e) {
      this.TratarErro(e);
      this.carregando = false;
    }
  }

  async alterarStatus(novo_status: number, agendamento?: Agendamento) {
    try {
      if (novo_status === 2 || novo_status === 3) {
        const resposta = await Util.Confirm(
          'Esta alteração não poderá mais ser desfeita, confirma?'
        );

        if (!resposta.isConfirmed) {
          return;
        }

        if (novo_status === 3) {
          const { value: motivo } = await Util.EspecificarTexto(
            'Motivo',
            'Qual o motivo do cancelamento?'
          );

          if (motivo) {
            this.agendamento.motivo_cancelamento = motivo.toString();
            if (agendamento) {
              agendamento.motivo_cancelamento = motivo.toString();
            }
          } else {
            return;
          }
        }
      }

      if (agendamento) {
        //função para pegar o horario_inicio que não esta preenchido!!
        //ele pega os 4 numeros depois do T da data do agendametno no padrão dd_MM_yyyy_hh_mm_ss para preencher o horario_inicio
        agendamento.horario_inicio = agendamento.data_inicial
          .toString()
          .slice(
            agendamento.data_inicial.toString().indexOf("T") + 1,
            agendamento.data_inicial.toString().indexOf("T") + 6
          )
          .replace(":", "");

        agendamento.horario_fim = agendamento.data_final
          .toString()
          .slice(
            agendamento.data_final.toString().indexOf("T") + 1,
            agendamento.data_final.toString().indexOf("T") + 6
          )
          .replace(":", "");

        const day = agendamento.dia_inicial;
        const month = agendamento.mes_inicial;
        const year = agendamento.ano_inicial;

        agendamento = {
          ...agendamento,
          data_auxiliar: {
            day,
            month,
            year,
          },
        };

        this.agendamento = agendamento;
      }

      this.agendamento.status = novo_status;
      this.OnSalvar();
    } catch (e) {
      this.TratarErro(e);
    }
  }

  openModalOpcoes() {
    this.modalService.open(this.modalOpcoes, { size: "lg", centered: true });
  }

  onChange(arg: EventChangeArg) {
    try {
      let agendamento = this.agendamentos.find((c) => c.id === +arg.event.id);
      if (agendamento && agendamento.status !== 2 && agendamento.status !== 3) {
        agendamento._data_inicial = Util.GetDataFormatada(
          arg.event.start ?? undefined,
          'yyyy-MM-dd HH:mm:ss'
        );

        agendamento._data_final = Util.GetDataFormatada(
          arg.event.end ?? undefined,
          'yyyy-MM-dd HH:mm:ss'
        );
        this.agendamentoSrv.setAgendamento(agendamento).subscribe({
          next: (r) => {
            if (r.success) {
              if (r.retorno == null) {
                this.agendamento = new Agendamento();
                Util.AlertWarning(`Medico ${this.medico.nome} não atende no horário desejado!`);
                this.tentando_salvar = this.salvando = this.carregando = false;
                this.ngOnChanges()
                return;
              }

              Util.NotificacaoSucesso('Agendamento alterado com sucesso!');
            } else {
              this.TratarErro(r.message);
            }
            this.consultarAgendamentos();
          },
          error: (e) => {
            {
              this.TratarErro(e);
              this.consultarAgendamentos();
            }
          },
        });
      } else {
        Util.AlertInfo('Não é mais possível alterar esse agendamento!');
        this.CarregarDadosCalendario();
      }
    } catch (e) {
      this.TratarErro(e);
    }
  }

  onMudouPeriodo(arg: DatesSetArg) {
    this.data_inicial = arg.start;
    this.data_final = arg.end;
    setTimeout(() => {
      this.consultarAgendamentos();
    }, 100);
  }

  CarregarDadosCalendario() {
    try {
      const calendario = this.calendarComponent.getApi();
      calendario.removeAllEvents();
      this.agendamentos.forEach((agendamento) => {
        const horario_inicial = Util.GetDataFormatada(
          agendamento.data_inicial,
          'HHmm'
        )?.toString();
        const horario_final = Util.GetDataFormatada(
          agendamento.data_final,
          'HHmm'
        )?.toString();
        calendario.addEvent({
          id: agendamento.id.toString(),
          title: agendamento.paciente,
          start: agendamento.data_inicial,
          end: agendamento.data_final,
          //hora e minuto tudo zero
          allDay: horario_inicial === '0000' && horario_final === '0000',
          //backgroundColor: agendamento.cor_agendamento,
          //borderColor: agendamento.cor_agendamento,
          backgroundColor: 'rgba(1,104,250, .15)',
          borderColor: agendamento.cor_agendamento,
          display: 'block',
          description: agendamento.observacao,
        });
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  consultarAgendamentos() {
    try {
      this.carregando = true;
      this.agendamentos = [];
      this.agendamentoSrv
        .getAgendamentos(
          this.auth.getMedicoSelecionado().id_usuario,
          this.auth.getEmpresaLogada().id_empresa_acessar,
          this.data_inicial,
          this.data_final
        )
        .subscribe({
          next: (retorno) => {
            if (retorno.success) {
              this.agendamentos = retorno.retorno;
              this.CarregarDadosCalendario();
            } else {
              this.TratarErro(retorno.message);
            }
            this.carregando = false;
          },
          error: (e) => {
            this.TratarErro(e);
          },
        });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  novoAgendamento(selectInfo: DateSelectArg) {
    this.agendamento = new Agendamento();
    this.agendamento.data_inicial = selectInfo.start;
    this.agendamento.data_final = selectInfo.end;
    this.agendamento.id_empresa =
      this.auth.getEmpresaLogada().id_empresa_acessar;
    if (this.auth.getColaboradorLogado().tipo_usuario_nosso_dr == 0) {
      this.agendamento.id_atendente =
        this.auth.getAtendenteSelecionado().id_usuario;
    } else {
      this.agendamento.id_atendente =
        this.auth.getMedicoSelecionado().id_usuario;
    }
    this.agendamento.id_medico = this.auth.getMedicoSelecionado().id_usuario;

    this.showTelaAgendamento(
      this.agendamento,
      selectInfo.start.getUTCDate(),
      selectInfo.start.getUTCMonth() + 1,
      selectInfo.start.getUTCFullYear()
    );
  }

  showTelaAgendamento(
    agendamento: Agendamento,
    day: number,
    month: number,
    year: number
  ) {
    this.tentando_salvar = false;

    this.agendamento = {
      ...agendamento,
      data_auxiliar: {
        day,
        month,
        year,
      },
    };

    this.agendamento.horario_inicio = Util.GetDataFormatada(
      agendamento.data_inicial,
      'HH:mm'
    );
    this.agendamento.horario_fim = Util.GetDataFormatada(
      agendamento.data_final,
      'HH:mm'
    );

    if (this.auth.getColaboradorLogado().tipo_usuario_nosso_dr == 0) {
      this.agendamento.agendado_por = this.auth.getAtendenteSelecionado().nome;
    } else {
      this.agendamento.agendado_por = this.auth.getMedicoSelecionado().nome;
    }

    //preencho o lookup do cliente
    this.lookup_cliente = new ClienteLookup();
    if (agendamento.id > 0) {
      this.lookup_cliente.objeto_selecionado = {
        cod: this.agendamento.id_cliente.toString(),
        descricao: this.agendamento.paciente,
        telefone: this.agendamento.telefone
      };
      this.openModalOpcoes();
    } else {
      this.lookup_cliente.objeto_selecionado = new LookupModel();
      //limpo o horario final pro usuario ter q digitar
      this.agendamento.horario_fim = '';
      this.openModalAgendamento();
    }
  }

  onClicou(clickInfo: EventClickArg) {
    try {
      const agenda = this.agendamentos.find((c) => c.id == +clickInfo.event.id);
      if (agenda) {
        this.showTelaAgendamento(
          agenda,
          agenda.dia_inicial,
          agenda.mes_inicial,
          agenda.ano_inicial
        );
      } else {
        Util.NotificacaoAlerta('Opa, agendamento não localizado...');
      }
    } catch (e) {
      this.TratarErro(e);
    }
  }

  override getTitulo(): string {
    return 'Agendamentos';
  }

  override OnSalvar() {
    try {
      this.tentando_salvar = true;
      this.agendamento.horario_fim = this.agendamento.horario_fim?.replace(
        ':',
        ''
      );
      this.agendamento.horario_inicio =
        this.agendamento.horario_inicio?.replace(':', '');
      if (
        (this.agendamento.id_cliente ||
          this.lookup_cliente?.objeto_selecionado?.cod) &&
        this.agendamento.status >= 0 &&
        this.agendamento.tipo_agendamento >= 0 &&
        this.agendamento.data_auxiliar &&
        this.agendamento.horario_fim?.length === 4 &&
        this.agendamento.horario_inicio?.length === 4
      ) {
        this.salvando = true;
        let parte = this.agendamento.horario_inicio.substring(0, 2);
        const inicio_hora = +parte;
        parte = this.agendamento.horario_inicio.substring(2, 4);
        const inicio_minuto = +parte;
        parte = this.agendamento.horario_fim.substring(0, 2);
        const fim_hora = +parte;
        parte = this.agendamento.horario_fim.substring(2, 4);
        const fim_minuto = +parte;
        this.agendamento._data_inicial = Util.GetDataFormatada(
          Util.NgbDateStructToDate(
            this.agendamento.data_auxiliar,
            +inicio_hora,
            +inicio_minuto
          ),
          'yyyy-MM-dd HH:mm:ss'
        );
        this.agendamento._data_final = Util.GetDataFormatada(
          Util.NgbDateStructToDate(
            this.agendamento.data_auxiliar,
            +fim_hora,
            +fim_minuto
          ),
          'yyyy-MM-dd HH:mm:ss'
        );

        if (this.auth.getColaboradorLogado().tipo_usuario_nosso_dr == 0) {
          this.agendamento.id_atendente_update =
            this.auth.getAtendenteSelecionado().id_usuario;
        } else {
          this.agendamento.id_atendente_update =
            this.auth.getMedicoSelecionado().id_usuario;
        }

        if (this.lookup_cliente.objeto_selecionado?.cod) {
          this.agendamento.id_cliente =
            +this.lookup_cliente.objeto_selecionado.cod;
        } else +this.agendamento.id_cliente;

        if (this.agendamento.horario_inicio == this.agendamento.horario_fim) {
          Util.AlertWarning(
            `horario inicial ${this.agendamento.horario_inicio} é igual ao horario final ${this.agendamento.horario_fim}`
          );
          this.tentando_salvar = this.salvando = this.carregando = false;
          return;
        }

        this.agendamentoSrv.setAgendamento(this.agendamento).subscribe((r) => {
          if (r.success) {
            if (r.retorno == null) {
              this.agendamento = new Agendamento();
              Util.AlertWarning(`Medico ${this.medico.nome} não atende no horário desejado!`);
              this.tentando_salvar = this.salvando = this.carregando = false;
              this.ngOnChanges()
              return;
            }

            Util.NotificacaoSucesso('Salvo com sucesso!');
            if (this.agendamento.id > 0) {
              let localizar = this.agendamentos.find(
                (c) => c.id === this.agendamento.id
              );
              //removo da lista
              if (localizar) {
                this.agendamentos.splice(
                  this.agendamentos.indexOf(localizar),
                  1
                );
              }
              this.ngOnChanges();
            }

            //adiciono caso n esteja cancelando
            if (this.agendamento.status !== 3) {
              //gambis pra preencher o paciente no agendamento local
              r.retorno.paciente =
                this.lookup_cliente.objeto_selecionado.descricao;
              r.retorno.telefone =
                this.lookup_cliente.objeto_selecionado.telefone;
              this.agendamentos.push(r.retorno);
            }

            this.CarregarDadosCalendario();
            this.modalService.dismissAll();
            this.tentando_salvar = this.carregando = false;
          } else {
            Util.TratarErro(r.message);
          }
          this.salvando = this.tentando_salvar = false;
        });
      } else {
        Util.AlertWarning('Corrija os campos inválidos');
      }
    } catch (e) {
      this.TratarErro(e);
    }
  }

  pegarAgendamentosCancelados() {
    try {
      this.carregando = true;
      const id = this.auth.getMedicoSelecionado().id_usuario;
      this.agendamentoSrv.getAgendamentosCancelados(id).subscribe({
        next: (r) => {
          if (r.success) {
            this.agendamentos_cancelados = r.retorno;
            this.carregando = false;
            this.modalService.open(this.modalCancelados, { size: "lg", centered: true });
          } else {
            Util.TratarErro(r.message);
          }
        },
      });
    } catch (e) {
      Util.TratarErro(e);
    }
  }

  pegarAgendamentosNaoConfirmados() {
    try {
      const id = this.auth.getMedicoSelecionado().id_usuario;
      this.agendamentoSrv.getAgendamentosNaoConfirmados(id).subscribe({
        next: (r) => {
          if (r.success) {
            this.agendamentos_naoconfirmados = r.retorno;
            this.carregando = false;
            this.modalService.open(this.modalNaoConfirmados, { size: "lg", centered: true });
          } else {
            Util.TratarErro(r.message);
          }
        },
      });
    } catch (e) {
      Util.TratarErro(e);
    }
  }
}
