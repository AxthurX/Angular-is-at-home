import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';

export class Agendamento {
  id: number = 0;
  tipo_agendamento: number = 0;
  id_empresa: number;
  id_cliente: number;
  id_medico: number;
  id_atendente: number;
  id_atendente_update: number;
  status: number = 0;
  data_auxiliar: NgbDateStruct;
  data_inicial: Date;
  _data_inicial?: string;
  data_final: Date;
  _data_final?: string;
  horario_inicio?: string;
  horario_fim?: string;
  motivo_cancelamento: string;
  observacao: string;
  triagem_temperatura?: number;
  triagem_peso?: number;
  triagem_altura?: number;
  triagem_observacao: string;

  //campos auxiliares
  cor_agendamento?: string;
  dia_inicial: number;
  mes_inicial: number;
  ano_inicial: number;
  tipo_agendamento_descricao: string;
  status_descricao: string;
  agendado_por: string;
  agendado_para: string;
  horario_descricao: string;
  telefone?: string;
  paciente: string;
  idade?: number;
  consentimento_lgpd?: boolean;
  email: string;
  cpf_cnpj: string;
}
