import { NgModule } from "@angular/core";
import { ConvenioComponent } from "./convenio.component";
import { SharedModule } from "src/app/nosso-dr/core/shared.module";
import { ReactiveFormsModule } from "@angular/forms";
import { RouterModule, Routes } from "@angular/router";
import { NgSelectModule } from "@ng-select/ng-select";
import { NgxMaskModule } from "ngx-mask";
import { NgbActiveModal } from "@ng-bootstrap/ng-bootstrap";

const routes: Routes = [
  {
    path: "",
    component: ConvenioComponent,
  },
];

@NgModule({
  declarations: [ConvenioComponent],
  imports: [
    SharedModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes),
    NgSelectModule,
    NgxMaskModule.forRoot({ validation: true }),
  ],
  providers: [NgbActiveModal],
})
export class ConvenioModule {}
