import { Component, ElementRef, OnChanges, OnInit, ViewChild } from "@angular/core";
import { NgbActiveModal, NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { ClasseBase } from "src/app/nosso-dr/core/model/classe-base.model";
import { AuthService } from "src/app/nosso-dr/core/services/auth.service";
import { Categorias, Convenio, ConvenioJson, Credenciados, DemaisDados, Discriminativo, Faturamento, PorteMatMed, PortePrc } from "./convenio.model";
import { ConvenioService } from "src/app/nosso-dr/core/services/convenio.service";
import { Util } from "src/app/nosso-dr/core/util.model";
import { ClienteService, RetornoEndereco } from "src/app/nosso-dr/core/services/cliente.service";
@Component({
  selector: "app-convenio",
  templateUrl: "./convenio.component.html",
  styleUrls: ["./convenio.component.scss"],
})
export class ConvenioComponent extends ClasseBase implements OnInit, OnChanges {
  @ViewChild("modalDetalhePrc", { static: true }) modalDetalhePrc: ElementRef;
  @ViewChild("modalDetalheMatMed", { static: true }) modalDetalheMatMed: ElementRef;
  @ViewChild("modalDetalheCategoria", { static: true }) modalDetalheCategoria: ElementRef;
  @ViewChild("modalEditarCategorias", { static: true }) modalEditarCategorias: ElementRef;
  @ViewChild("modalEditarCredenciados", { static: true }) modalEditarCredenciados: ElementRef;
  @ViewChild("modalEditarMatMed", { static: true }) modalEditarMatMed: ElementRef;
  @ViewChild("modalEditarPrc", { static: true }) modalEditarPrc: ElementRef;
  convenio = new Convenio();
  convenio_json = new ConvenioJson();
  credenciados = new Credenciados();
  lista_credenciados: Credenciados[] = [];
  faturamento = new Faturamento();
  categorias = new Categorias();
  lista_categorias: Categorias[] = [];
  porte_matmed = new PorteMatMed();
  lista_porte_matmed: PorteMatMed[] = [];
  porte_prc = new PortePrc();
  lista_porte_prc: PortePrc[] = [];
  demais_dados = new DemaisDados();
  discriminativo: Discriminativo;
  consultandoMunicipios: boolean;
  consultandoBairros: boolean;
  consultandoEndereco: boolean;
  enderecoConsultado: RetornoEndereco;
  cat_prc: string;
  conv_prc: string;
  prest_prc: string;
  conv_matmed: string;
  cat_matmed: string;
  familia_matmed: string;
  subgrupo_familia_matmed: string;
  constructor(
    public actModal: NgbActiveModal,
    private modal: NgbModal,
    private convenioSrv: ConvenioService,
    private auth: AuthService,
    private clienteSrv: ClienteService
  ) {
    super();
  }

  ngOnInit(): void {
    try {
      this.ngOnChanges();
    } catch (e) {
      this.TratarErro(e);
    }
  }

  ngOnChanges() {
    try {
      this.getCredenciados();
      this.getCategorias();
      this.getPorteMatMed();
      this.getPortePrc();
    } catch (e) {
      this.TratarErro(e);
    }
  }

  override getTitulo(): string {
    return "Cadastro de convênio";
  }

  override async OnSalvar() {
    try {
      this.carregando = true;
      if (!this.convenio.id && !this.convenio.descricao) {
        Util.AlertWarning("Ops, corrija os campos inválidos");
        this.carregando = false;
        return;
      }

      this.carregando = true;
      if (
        !this.convenio.nro_convenio &&
        !this.convenio.modalidade_convenio &&
        !this.convenio.identifica_prestador_proprios &&
        !this.convenio.formula_validacao_cod_usuario &&
        !this.convenio.inativo &&
        !this.convenio.convenio_contratualizado
      ) {
        Util.AlertWarning(
          "Verifique se os campos dos convênio estão preenchidos antes de salvar!"
        );
        this.carregando = false;
        return;
      }

      this.convenio.json = JSON.stringify(this.convenio_json);
      this.convenioSrv.salvarConvenio(this.convenio).subscribe({
        next: (r) => {
          if (r.success) {
            Util.AlertSucess("Convenio salvo com sucesso!!");
            this.convenio_json = new ConvenioJson();
            this.convenio = new Convenio();
            this.carregando = false;
          } else {
            Util.TratarErro(r.message);
          }
        },
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  pesquisarPrc(conv: string, cat: string, prest: string): void {
    try {
      this.carregando = true;
      this.convenioSrv.pesquisarPrc(conv, cat, prest).subscribe({
        next: (r) => {
          this.carregando = false;
          if (r.success) {
            this.lista_porte_prc = r.retorno;
          } else {
            this.TratarErro(r.message);
          }
        },
        error: (e) => this.TratarErro(e),
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  onConsutarCEP(convenio: Convenio) {
    try {
      if (convenio.cep && convenio.cep.length === 8 && navigator.onLine) {
        this.consultandoEndereco = true;
        this.clienteSrv.consultaCEP(convenio.cep).subscribe({
          next: (endereco) => {
            this.enderecoConsultado = endereco;
            if (endereco.erro) {
              Util.AlertWarning(
                "CEP não localizado, verifique se está correto!"
              );
              this.consultandoEndereco = false;
            } else {
              convenio.complemento = endereco.complemento.toUpperCase();
              convenio.logradouro = endereco.logradouro.toUpperCase();
              convenio.municipio = endereco.localidade.toUpperCase();
              convenio.bairro = endereco.bairro.toUpperCase();
              convenio.uf = endereco.uf.toUpperCase();
            }
          },
        }),
          (e: any) => {
            Util.TratarErro(e);
            this.consultandoEndereco = false;
          };
      }
    } catch (e) {
      Util.TratarErro(e);
      this.consultandoEndereco = false;
    }
  }

  salvarDadosPrincipaisConvenio(form: any) {
    try {
      this.carregando = true;
      if (
        !this.convenio.nro_convenio &&
        !this.convenio.modalidade_convenio &&
        !this.convenio.identifica_prestador_proprios &&
        !this.convenio.formula_validacao_cod_usuario &&
        !this.convenio.inativo &&
        !this.convenio.convenio_contratualizado
      ) {
        Util.AlertWarning(
          "Verifique se os campos dos convênio estão preenchidos antes de salvar!"
        );
        this.carregando = false;
        return;
      }

      this.convenio = form.value;
      this.convenioSrv.salvarConvenio(this.convenio).subscribe({
        next: (r) => {
          if (r.success) {
            Util.AlertSucess("Convenio salvo com sucesso!!");
            this.convenio_json = new ConvenioJson();
            this.carregando = false;
          } else {
            Util.TratarErro(r.message);
          }
        },
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  salvarDemaisDados(form: any) {
    try {
      this.carregando = true;
      if (
        !this.convenio_json.forma_discriminacao_matmed &&
        !this.convenio_json.versao_schema_impressao &&
        !this.convenio_json.id_tipo_tab_med &&
        !this.convenio_json.id_tipo_tab_mat
      ) {
        Util.AlertWarning(
          "Verifique se os campos dos demais dados estão preenchidos antes de salvar!"
        );
        this.carregando = false;
        return;
      }

      this.demais_dados = form.value;
      this.demais_dados.id_convenio = this.convenio.id;
      this.convenioSrv.salvarDemaisDados(this.demais_dados).subscribe({
        next: (r) => {
          if (r.success) {
            Util.AlertSucess("Demais Dados salvo com sucesso!!");
            this.convenio_json = new ConvenioJson();
            this.carregando = false;
          } else {
            Util.TratarErro(r.message);
            this.carregando = false;
          }
        },
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  salvarCredenciados(form: any) {
    try {
      this.carregando = true;
      if (
        !this.convenio_json.medico &&
        !this.convenio_json.setor &&
        !this.convenio_json.nro_contato_com_plano &&
        !this.convenio_json.categoria
      ) {
        Util.AlertWarning(
          "Verifique se os campos dos credenciados estão preenchidos antes de salvar!"
        );
        this.carregando = false;
        return;
      }

      if (this.convenio_json.medico && this.convenio_json.categoria) {
        this.credenciados = form.value;
        this.credenciados.id_colaborador =
          this.auth.getColaboradorLogado().id_colaborador;
      }

      this.credenciados.id_convenio = this.convenio.id;
      this.convenioSrv.salvarCredenciados(this.credenciados).subscribe({
        next: (r) => {
          if (r.success) {
            Util.AlertSucess("Credenciado salvo com sucesso!!");
            this.convenio_json = new ConvenioJson();
            this.modal.dismissAll();
            this.carregando = false;
            this.ngOnChanges();
          } else {
            Util.TratarErro(r.message);
          }
        },
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  getCredenciados() {
    try {
      this.carregando = true;
      let id_colaborador = this.auth.getColaboradorLogado().id_colaborador;
      this.convenioSrv.getCredenciados(id_colaborador).subscribe({
        next: (r) => {
          if (r.success) {
            this.lista_credenciados = r.retorno;
            this.carregando = false;
          } else {
            Util.TratarErro(r.message);
          }
        },
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  salvarPortePrc(form: any) {
    try {
      this.carregando = true;
      if (
        !this.convenio_json.categoria_procedimento &&
        !this.convenio_json.prestador_procedimento &&
        !this.convenio_json.setor_procedimento &&
        !this.convenio_json.vigencia_procedimento
      ) {
        Util.AlertWarning(
          "Verifique se os campos de porte de procedimento estão preenchidos antes de salvar!"
        );
        this.carregando = false;
        return;
      }
      if (
        this.convenio_json.categoria_procedimento &&
        this.convenio_json.prestador_procedimento
      ) {
        this.porte_prc = form.value;
        this.porte_prc.id_colaborador =
          this.auth.getColaboradorLogado().id_colaborador;
      }
      this.porte_prc.id_convenio = this.convenio.id;
      this.porte_prc.descricao_convenio = this.convenio.descricao;
      this.convenioSrv.salvarPortePrc(this.porte_prc).subscribe({
        next: (r) => {
          if (r.success) {
            Util.AlertSucess("Procedimento salvo com sucesso!!");
            this.convenio_json = new ConvenioJson();
            this.modal.dismissAll();
            this.carregando = false;
            this.ngOnChanges();
          } else {
            Util.TratarErro(r.message);
          }
        },
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  getPortePrc() {
    try {
      this.carregando = true;
      let id_colaborador = this.auth.getColaboradorLogado().id_colaborador;
      this.convenioSrv.getPortePrc(id_colaborador).subscribe({
        next: (r) => {
          if (r.success) {
            this.lista_porte_prc = r.retorno;
            this.carregando = false;
          } else {
            Util.TratarErro(r.message);
          }
        },
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  openModalDetalhesPrc() {
    this.convenio_json = new ConvenioJson();
    this.modal.open(this.modalDetalhePrc, { size: "lg", centered: true });
  }

  editarPrc(prc: PortePrc) {
    this.porte_prc = prc;
    this.modal.open(this.modalEditarPrc, { size: "lg", centered: true });
  }

  salvarPorteMatMed(form: any) {
    try {
      this.carregando = true;
      if (
        !this.convenio_json.categoria_matmed &&
        !this.convenio_json.familia_matmed &&
        !this.convenio_json.subgrupo_familia_matmed &&
        !this.convenio_json.vigencia_matmed
      ) {
        Util.AlertWarning(
          "Verifique se os campos de porte de materiais e medicamentos estão preenchidos antes de salvar!"
        );
        this.carregando = false;
        return;
      }

      if (this.convenio_json.id_convenio_matmed) {
        this.porte_matmed = form.value;
        this.porte_matmed.id_colaborador =
          this.auth.getColaboradorLogado().id_colaborador;
      }
      this.porte_matmed.id_convenio = this.convenio.id;
      this.convenioSrv.salvarPorteMatMed(this.porte_matmed).subscribe({
        next: (r) => {
          if (r.success) {
            Util.AlertSucess("Materias e Medicamentos salvo com sucesso!!");
            this.convenio_json = new ConvenioJson();
            this.modal.dismissAll();
            this.carregando = false;
            this.ngOnChanges();
          } else {
            Util.TratarErro(r.message);
            this.carregando = false;
          }
        },
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  openModalDetalhesMatMed() {
    this.convenio_json = new ConvenioJson();
    this.modal.open(this.modalDetalheMatMed, { size: "lg", centered: true });
  }

  getPorteMatMed() {
    try {
      this.carregando = true;
      let id_colaborador = this.auth.getColaboradorLogado().id_colaborador;
      this.convenioSrv.getPorteMatMed(id_colaborador).subscribe({
        next: (r) => {
          if (r.success) {
            this.lista_porte_matmed = r.retorno;
            this.carregando = false;
          } else {
            Util.TratarErro(r.message);
          }
        },
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  pesquisarMatMed(
    conv: string,
    cat: string,
    familia: string,
    subgrupo_familia: string
  ): void {
    try {
      this.carregando = true;
      this.convenioSrv
        .pesquisarMatMed(conv, cat, familia, subgrupo_familia)
        .subscribe({
          next: (r) => {
            this.carregando = false;
            if (r.success) {
              this.lista_porte_matmed = r.retorno;
            } else {
              this.TratarErro(r.message);
            }
          },
          error: (e) => this.TratarErro(e),
        });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  editarMatMed(matmed: PorteMatMed) {
    this.porte_matmed = matmed;
    this.modal.open(this.modalEditarMatMed, { size: "lg", centered: true });
  }

  openModalDetalhesCategoria() {
    this.convenio_json = new ConvenioJson();
    this.modal.open(this.modalDetalheCategoria, { size: "xl", centered: true });
  }

  salvarCategoria(form: any) {
    try {
      this.carregando = true;
      if (
        !this.convenio_json.modalidade_atendimento &&
        !this.convenio_json.tab_srv_hosp &&
        !this.convenio_json.tab_sadt &&
        !this.convenio_json.tab_med
      ) {
        Util.AlertWarning(
          "Verifique se os campos de categorias estão preenchidos antes de salvar!"
        );
        this.carregando = false;
        return;
      }

      if (this.convenio_json.categoria && this.convenio_json.especificacao_categoria) {
        this.categorias = form.value;
        this.categorias.id_colaborador =
          this.auth.getColaboradorLogado().id_colaborador;
      }

      this.categorias.id_convenio = this.convenio.id;
      this.convenioSrv.salvarCategorias(this.categorias).subscribe({
        next: (r) => {
          if (r.success) {
            Util.AlertSucess("Categorias salva com sucesso!!");
            this.convenio_json = new ConvenioJson();
            this.modal.dismissAll();
            this.ngOnChanges();
            this.carregando = false;
          } else {
            Util.TratarErro(r.message);
          }
        },
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  editarCategoria(categorias: Categorias) {
    this.categorias = categorias;
    this.modal.open(this.modalEditarCategorias, { size: "xl", centered: true });
  }

  getCategorias() {
    try {
      this.carregando = true;
      let id_colaborador = this.auth.getColaboradorLogado().id_colaborador;
      this.convenioSrv.getCategorias(id_colaborador).subscribe({
        next: (r) => {
          if (r.success) {
            this.lista_categorias = r.retorno;
            this.carregando = false;
          } else {
            Util.TratarErro(r.message);
          }
        },
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  salvarFaturamento(form: any) {
    try {
      this.carregando = true;
      if (
        !this.convenio_json.ultilizar_macro_categoria &&
        !this.convenio_json.grupo_faturamento &&
        !this.convenio_json.condicao_parcelamento &&
        !this.convenio_json.campo_impressao_fatura
      ) {
        Util.AlertWarning(
          "Verifique se os campos de faturamento estão preenchidos antes de salvar!"
        );
        this.carregando = false;
        return;
      }

      this.faturamento.id_convenio = this.convenio.id;
      this.faturamento.descricao_convenio = this.convenio.descricao;
      this.faturamento = form.value;
      this.faturamento.id_colaborador =
        this.auth.getColaboradorLogado().id_colaborador;
      this.convenioSrv.salvarFaturamento(this.faturamento).subscribe({
        next: (r) => {
          if (r.success) {
            Util.AlertSucess("Faturamento salvo com sucesso!!");
            this.convenio_json = new ConvenioJson();
            this.carregando = false;
          } else {
            Util.TratarErro(r.message);
          }
        },
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  salvarDiscriminativo(form: any) {
    try {
      this.carregando = true;
      if (
        !this.convenio_json.emite_somente_com_sp_direto &&
        !this.convenio_json.imprime_vlr_do_ch_na_col_vlr_unitario &&
        !this.convenio_json.imprime_informacoes_parto_ans
      ) {
        Util.AlertWarning(
          "Verifique se os campos de discriminativo estão preenchidos antes de salvar!"
        );
        this.carregando = false;
        return;
      }

      this.discriminativo.id_convenio = this.convenio.id;
      this.discriminativo = form.value;
      this.convenioSrv.salvarDiscriminativo(this.discriminativo).subscribe({
        next: (r) => {
          if (r.success) {
            Util.AlertSucess("Discriminativo salvo com sucesso!!");
            this.convenio_json = new ConvenioJson();
            this.carregando = false;
          } else {
            Util.TratarErro(r.message);
          }
        },
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  editarCredenciados(credenciados: Credenciados) {
    this.credenciados = credenciados;
    this.modal.open(this.modalEditarCredenciados, { size: "lg", centered: true });
  }
}
