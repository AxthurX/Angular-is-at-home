import { Component, ElementRef, OnInit, ViewChild } from "@angular/core";
import { NgbActiveModal, NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { ClasseBase } from "src/app/nosso-dr/core/model/classe-base.model";
import { AuthService } from "src/app/nosso-dr/core/services/auth.service";
import { Colaborador } from "./colaborador.model";
import { ColaboradorService } from "src/app/nosso-dr/core/services/colaborador.service";
import { Util } from "src/app/nosso-dr/core/util.model";
import { Bairro, Municipio, UF } from "../cliente/cliente.model";
import { ClienteService, RetornoEndereco } from "src/app/nosso-dr/core/services/cliente.service";

@Component({
  selector: "app-colaborador",
  templateUrl: "./colaborador.component.html",
  styleUrls: ["./colaborador.component.scss"],
})
export class ColaboradorComponent extends ClasseBase implements OnInit {
  @ViewChild("modalPrincipal", { static: true }) modalPrincipal: ElementRef;
  tipos_situacao = Util.GetTiposSituacao();
  colaboradores: Colaborador[] = [];
  colaborador: Colaborador;
  enderecoConsultado: RetornoEndereco;
  consultandoEndereco: boolean;
  consultandoMunicipios: boolean;
  consultandoBairros: boolean;
  cadastrando_bairro: boolean;
  consultando: boolean;
  reorderable = true;
  bairro_descricao: string;
  ufs: UF[] = [];
  municipios: Municipio[] = [];
  bairros: Bairro[] = [];

  constructor(
    public actModal: NgbActiveModal,
    private modal: NgbModal,
    private srv: ColaboradorService,
    private utilSrv: ClienteService,
    private auth: AuthService
  ) {
    super();
  }

  ngOnInit() {
    try {
      this.utilSrv.getUf().subscribe((retorno) => {
        if (retorno.success) {
          this.ufs = retorno.retorno;
        } else {
          this.TratarErro(retorno.message);
        }
        this.carregando = false;
      });
    } catch (e) {
      Util.TratarErro(e);
      this.consultando = false;
    }
  }

  setFocusDocumento() {
    try {
      setTimeout(() => {
        document.getElementById("razao")?.focus();
      }, 500);
    } catch (e) {
      console.error("setFocusDocumento", e);
    }
  }

  override getTitulo(): string {
    return "Cadastro de colaboradores";
  }

  override OnPesquisar(texto: string): void {
    try {
      this.carregando = true;
      this.srv.pesquisar(texto).subscribe({
        next: (r) => {
          this.carregando = false;
          if (r.success) {
            this.colaboradores = r.retorno;
          } else {
            this.TratarErro(r.message);
          }
        },
        error: (e) => this.TratarErro(e),
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  override OnCadastrar(): void {
    this.colaborador = new Colaborador();
    this.openModal();
  }

  override OnEditar(objeto: any): void {
    this.colaborador = objeto;
    this.openModal();
    this.PrencherDados(this.colaborador);
  }

  override async OnSalvar() {
    this.tentando_salvar = true;
    try {
      if (
        !this.colaborador.razao &&
        !this.colaborador.email &&
        !this.colaborador.cpf_cnpj &&
        !this.colaborador.ativo
      ) {
        this.tentando_salvar = false;
        Util.AlertWarning("Ops, corrija os campos inválidos");
        return;
      }

      if (
        !this.colaborador.cep &&
        !this.colaborador.tipo_logradouro &&
        !this.colaborador.ufSelecionada &&
        !this.colaborador.municipioSelecionado &&
        !this.colaborador.municipioSelecionado
      ) {
        Util.AlertWarning(
          "Verifique se os campos de endereço estão preenchidos antes de salvar!"
        );
        this.tentando_salvar = false;
        return;
      }

      this.setSalvando();
      this.colaborador.id_uf = this.colaborador.ufSelecionada.id;
      this.colaborador.id_municipio = this.colaborador.municipioSelecionado.id;
      this.colaborador.id_bairro = this.colaborador.municipioSelecionado?.id;
      this.colaborador.id_empresa = this.auth.getEmpresaLogada().id;
      this.srv.salvar(this.colaborador).subscribe({
        next: (r) => {
          if (r.success) {
            this.colaboradores = r.retorno;
            this.Success("Colaborador salvo com sucesso!");
          } else {
            this.Error(r.message);
          }
        },
        error: (e) => this.TratarErro(e),
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  openModal() {
    this.modal.open(this.modalPrincipal, { size: "xl", centered: true });
    this.setFocusDocumento();
  }

  PrencherDados(colaborador: Colaborador) {
    const uf = this.ufs.find((c) => c.id === colaborador.id_uf);
    if (uf) {
      this.colaborador.ufSelecionada = uf;
    }

    this.utilSrv.getMunicipio(colaborador?.id_uf).subscribe((municipios) => {
      this.municipios = municipios.retorno;
      const municipio = this.municipios.find(
        (c) => c.id === colaborador.id_municipio
      );
      if (municipio) {
        this.colaborador.municipioSelecionado = municipio;
      }
    });

    this.utilSrv.getBairro(colaborador?.id_municipio).subscribe((bairros) => {
      this.bairros = bairros.retorno;
      const bairro = this.bairros.find((c) => c.id === colaborador.id_bairro);
      if (bairro) {
        this.colaborador.bairroSelecionado = bairro;
      }
    });
  }

  onConsutarCEP() {
    try {
      if (this.colaborador.cep && this.colaborador.cep.length === 8 && navigator.onLine) {
        this.consultandoEndereco = true;
        this.utilSrv.consultaCEP(this.colaborador.cep).subscribe({
          next: (endereco) => {
            this.enderecoConsultado = endereco;
            if (endereco.erro) {
              Util.AlertWarning(
                "CEP não localizado, verifique se está correto!"
              );
              this.consultandoEndereco = false;
            } else {
              this.colaborador.complemento = endereco.complemento.toUpperCase();
              this.colaborador.logradouro = endereco.logradouro.toUpperCase();

              //consulto a uf
              const uf = this.ufs.find(
                (c) => c.sigla.toLocaleUpperCase() === endereco.uf.toUpperCase()
              );
              if (uf) {
                this.colaborador.ufSelecionada = uf;
              }

              this.preencherMunicipios(this.colaborador.ufSelecionada);
              this.consultandoEndereco = false;
            }
          },
        });
        (e: any) => {
          Util.TratarErro(e);
          this.consultandoEndereco = false;
        };
      }
    } catch (e) {
      Util.TratarErro(e);
      this.consultandoEndereco = false;
    }
  }

  onAlterouUF(ev: UF) {
    try {
      this.preencherMunicipios(ev);
    } catch (e) {
      Util.TratarErro(e);
    }
  }

  onAlterouBairro(ev: Bairro) {
    try {
      this.colaborador.bairroSelecionado = ev;
    } catch (e) {
      Util.TratarErro(e);
    }
  }

  preencherMunicipios(uf: UF) {
    try {
      this.consultandoMunicipios = true;
      this.colaborador.ufSelecionada = uf;
      this.bairros = [];
      this.municipios = [];

      this.utilSrv
        .getMunicipio(this.colaborador.ufSelecionada?.id as number)
        .subscribe((retorno2) => {
          this.municipios = retorno2.retorno;
          const ret = this.municipios.find(
            (c) =>
              c.codigo.toUpperCase() ===
                this.enderecoConsultado?.ibge?.toUpperCase()
          );
          if (ret) {
            this.colaborador.municipioSelecionado = ret;
          }

          if (this.colaborador.municipioSelecionado) {
            this.utilSrv
              .getBairro(this.colaborador.municipioSelecionado?.id as number)
              .subscribe((retorno) => {
                this.bairros = retorno.retorno;
                if (this.enderecoConsultado && !this.enderecoConsultado.bairro) {
                  //consultou um cep geral, n veio bairro, falo q é centro, foda-se
                  this.enderecoConsultado.bairro = "CENTRO";
                }
                const bairro = this.bairros.find(
                  (c) =>
                    c.descricao.toUpperCase() ===
                    this.enderecoConsultado?.bairro?.toUpperCase()
                );
                if (bairro) {
                  this.colaborador.bairroSelecionado = bairro;
                }
                //consultou o cep mas n achou o bairro
                if (!this.colaborador.bairroSelecionado && this.enderecoConsultado) {
                  this.bairro_descricao = this.enderecoConsultado.bairro;
                  this.cadastrando_bairro = true;
                }

                this.consultandoBairros = false;
              });
          }

          this.carregando = false;
        });
    } catch (e) {
      Util.TratarErro(e);
      this.consultandoMunicipios = false;
    }
  }

  onAlterouMunicipio(ev: Municipio) {
    try {
      this.consultandoBairros = true;
      this.colaborador.municipioSelecionado = ev;
      this.bairros = [];
      this.utilSrv
        .getBairro(this.colaborador.municipioSelecionado?.id as number)
        .subscribe((retorno) => {
          this.bairros = retorno.retorno;

          if (this.enderecoConsultado && !this.enderecoConsultado.bairro) {
            //consultou um cep geral, n veio bairro, falo q é centro, foda-se
            this.enderecoConsultado.bairro = "CENTRO";
          }

          const bairro = this.bairros.find(
            (c) =>
              c.descricao.toUpperCase() ===
              this.enderecoConsultado?.bairro?.toUpperCase()
          );
          if (bairro) {
            this.colaborador.bairroSelecionado = bairro;
          }
          this.bairro_descricao = "";
          this.cadastrando_bairro = false;

          //consultou o cep mas n achou o bairro
          if (!this.colaborador.bairroSelecionado && this.enderecoConsultado) {
            this.bairro_descricao = this.enderecoConsultado.bairro;
            this.cadastrando_bairro = true;
          }

          this.consultandoBairros = false;
        });
    } catch (e) {
      Util.TratarErro(e);
      this.consultandoBairros = false;
    }
  }
}
