import { Bairro, Municipio, UF } from "../cliente/cliente.model";

export class Colaborador {
  id: number;
  id_erp: number;
  id_empresa: number;
  email: string;
  razao: string;
  fantasia: string;
  ativo: boolean;
  cpf_cnpj: string;
  rg: string;
  cnh: string;
  telefone_principal: string;
  telefone_whatsapp: string;
  cep: string;
  logradouro: string;
  numero: string;
  complemento: string;
  _data_nascimento: string;
  idade?: number;
  tipo_logradouro: string;
  id_uf: number;
  id_municipio: number;
  id_bairro: number;
  municipioSelecionado: Municipio;
  bairroSelecionado: Bairro;
  ufSelecionada: UF;
}
