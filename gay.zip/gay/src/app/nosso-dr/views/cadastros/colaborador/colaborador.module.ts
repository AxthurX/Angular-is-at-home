import { NgModule } from "@angular/core";
import { ColaboradorComponent } from "./colaborador.component";
import { SharedModule } from "src/app/nosso-dr/core/shared.module";
import { ReactiveFormsModule } from "@angular/forms";
import { RouterModule, Routes } from "@angular/router";
import { NgSelectModule } from "@ng-select/ng-select";
import { NgxMaskModule } from "ngx-mask";
import { NgbActiveModal } from "@ng-bootstrap/ng-bootstrap";

const routes: Routes = [
  {
    path: "",
    component: ColaboradorComponent,
  },
];

@NgModule({
  declarations: [ColaboradorComponent],
  imports: [
    SharedModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes),
    NgSelectModule,
    NgxMaskModule.forRoot({ validation: true }),
  ],
  providers: [NgbActiveModal],
})
export class ColaboradorModule {}
