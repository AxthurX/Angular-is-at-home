export class Procedimento {
  id: number;
  descricao: string;

  //Demais Dados
  nro_procedimento_demaisdados: number;
  procedimentos_demaisdados: string;
  id_procedimentos_cobranca_demaisdados: number;
  descricao_procedimentos_cobranca_demaisdados: string;
  id_tipo_ato_medico: number;
  descricao_tipo_ato_medico: string;
  id_fator_cobranca: number;
  descricao_fator_cobranca: string;
  id_tipo_tabela_procedimento_tiss: number;
  descricao_tipo_tabela_procedimento_tiss: string;
  qtde_limite_uso: number;
  identifica_consulta_eletiva: boolean;
  permitir_varias_ocorrencias: boolean;
  preco_definido_pelo_gestor: boolean;
  complexidade: boolean;
  permitir_longa_permanencia: boolean;
  cod_variavel: boolean;
  envio_segmentado_por_data: boolean;
  imprimir_solicitacao_exame_prescricao: boolean;
  doc: string;

  //Cobrança
  id_procedimento_cobranca: number;
  descricao_procedimento_cobranca: string;
  id_primeiro_tipo_movimento: number;
  descricao_primeiro_tipo_movimento: string;
  id_segundo_tipo_movimento: number;
  descricao_segundo_tipo_movimento: string;
  id_terceiro_tipo_movimento: number;
  descricao_terceiro_tipo_movimento: string;

  //Composição
  nro_tabela_composicao: number;
  tipo_tabela_procedimento: string;
  cod_procedimento_composicao: number;
  validade: string;
  especificacao: string;
  especificacao_simplificada: string;
  duracao_prevista_cirurgia: string;
  especialidade_basica_aih: string;
  especialidade: string;
  classificacao_procedimentos: string;
  natureza_despesa_tiss: string;
  id_procedimento_tabela_tuss: number;
  descricao_procedimento_tabela_tuss: string;
  id_tecnica_utilizada_tiss: number;
  descricao_tecnica_utilizada_tiss: string;
  pacote_cobranca: boolean;
  nao_envia_ciha: boolean;
  cid10_relacionado: string;
  setor_relacionado: string;
  sexo_relacionado: string;
  tipo_anestesia: string;
  tipo_cirurgia: string;
  tipo_parto: string;
  faixa_etaria_inicial: string;
  faixa_etaria_final: string;
  tempo_limite_meses: string;
  duracao_cirurgia: string;
  pact_procedimento: boolean;
  procedimento_complemen: boolean;

  //Diagnósticos
  procedimento_diagnostico: string;
  doenca_cid: string;
  qtde_permitida_diagnosticos: number;

  //Compatibilidade
  procedimento_compatibilidade: string;
  procedimento_compativel: string;
  qtde_permitida_compatibilidade: number;
  tipo_procedimento: string;

  //Incompatibilidade
  procedimento_imcompatibilidade: string;
  procedimento_incompativel: string;
  qtde_permitida_incompatibilidade: number;

  //CBOSs
  procedimento_cbos: string;
  cod_cbos_tiss: number;
  qtde_permitida_cbos: number;
  compet_inicial: string;
  compet_final: string;
}

export class DemaisDados {
  id: number;
  nro_procedimento: number;
  procedimentos: string;
  id_procedimentos_cobranca: number;
  descricao_procedimentos_cobranca: string;
  id_tipo_ato_medico: number;
  descricao_tipo_ato_medico: string;
  id_fator_cobranca: number;
  descricao_fator_cobranca: string;
  id_tipo_tabela_procedimento_tiss: number;
  descricao_tipo_tabela_procedimento_tiss: string;
  qtde_limite_uso: string;
  identifica_consulta_eletiva: boolean;
  permitir_varias_ocorrencias: boolean;
  preco_definido_pelo_gestor: boolean;
  complexidade: boolean;
  permitir_longa_permanencia: boolean;
  cod_variavel: boolean;
  envio_segmentado_por_data: boolean;
  imprimir_solicitacao_exame_prescricao: boolean;
  doc: string;
}

export class Cobranca {
  id: number;
  id_colaborador: number;
  id_procedimento: number;
  descricao_procedimento: string;
  id_primeiro_tipo_movimento: number;
  descricao_primeiro_tipo_movimento: string;
  id_segundo_tipo_movimento: number;
  descricao_segundo_tipo_movimento: string;
  id_terceiro_tipo_movimento: number;
  descricao_terceiro_tipo_movimento: string;
}

export class Composicao {
  id: number;
  nro_tabela: number;
  tipo_tabela_procedimento: string;
  cod_procedimento: number;
  validade: string;
  especificacao: string;
  especificacao_simplificada: string;
  duracao_prevista_cirurgia: string;
  especialidade_basica_aih: string;
  especialidade: string;
  classificacao_procedimentos: string;
  natureza_despesa_tiss: string;
  id_procedimento_tabela_tuss: number;
  descricao_procedimento_tabela_tuss: string;
  id_tecnica_utilizada_tiss: number;
  descricao_tecnica_utilizada_tiss: string;
  pacote_cobranca: boolean;
  nao_envia_ciha: boolean;
  cid10_relacionado: string;
  setor_relacionado: string;
  sexo_relacionado: string;
  tipo_anestesia: string;
  tipo_cirurgia: string;
  tipo_parto: string;
  faixa_etaria_inicial: string;
  faixa_etaria_final: string;
  tempo_limite_meses: string;
  duracao_cirurgia: string;
  pact_procedimento: boolean;
  procedimento_complemen: boolean;
}

export class Diagnosticos {
  id: number;
  id_colaborador: number;
  procedimentos: string;
  doenca_cid: string;
  qtde_permitida: string;
}

export class Compatibilidade {
  id: number;
  id_colaborador: number;
  procedimentos: string;
  procedimento_compativel: string;
  qtde_permitida: string;
  tipo_procedimento: string;
}

export class Incompatibilidade {
  id: number;
  id_colaborador: number;
  procedimentos: string;
  procedimento_incompativel: string;
  qtde_permitida: string;
}

export class Cbos {
  id: number;
  id_colaborador: number;
  procedimentos: string;
  cod_cbos_tiss: string;
  qtde_permitida: string;
  compet_inicial: string;
  compet_final: string;
}
