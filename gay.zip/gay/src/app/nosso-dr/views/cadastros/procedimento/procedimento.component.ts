import { Component, OnChanges, OnInit } from "@angular/core";
import { NgbActiveModal } from "@ng-bootstrap/ng-bootstrap";
import { ClasseBase } from "src/app/nosso-dr/core/model/classe-base.model";
import {
  Cbos,
  Cobranca,
  Compatibilidade,
  Composicao,
  DemaisDados,
  Diagnosticos,
  Incompatibilidade,
  Procedimento,
} from "./procedimento.model";
import { ProcedimentoService } from "src/app/nosso-dr/core/services/procedimento.service";
import { Util } from "src/app/nosso-dr/core/util.model";
import { AuthService } from "src/app/nosso-dr/core/services/auth.service";
@Component({
  selector: "app-procedimento",
  templateUrl: "./procedimento.component.html",
  styleUrls: ["./procedimento.component.scss"],
})
export class ProcedimentoComponent extends ClasseBase implements OnInit, OnChanges {
  defaultNavActiveId = 3;
  procedimentos: Procedimento[] = [];
  procedimento: Procedimento;
  demais_dados: DemaisDados;
  cobranca: Cobranca;
  lista_cobranca: Cobranca[] = [];
  composicao: Composicao;
  diagnosticos: Diagnosticos;
  lista_diagnosticos: Diagnosticos[] = [];
  compatibilidade: Compatibilidade;
  lista_compatibilidade: Compatibilidade[] = [];
  incompatibilidade: Incompatibilidade;
  lista_incompatibilidade: Incompatibilidade[] = [];
  cbos: Cbos;
  lista_cbos: Cbos[] = [];
  constructor(
    public actModal: NgbActiveModal,
    private auth: AuthService,
    private procedimentoSrv: ProcedimentoService
  ) {
    super();
  }

  ngOnInit(): void {
    try {
      this.procedimento = new Procedimento();
      this.ngOnChanges();
    } catch (e) {
      this.TratarErro(e);
    }
  }

  ngOnChanges() {
    try {
      this.getCbos();
      this.getCobranca();
      this.getCompatibilidade();
      this.getDiagnosticos();
      this.getIncompatibilidade();
    } catch (e) {
      this.TratarErro(e);
    }
  }

  override getTitulo(): string {
    return "Cadastro de procedimento";
  }

  override async OnSalvar() {
    try {
      this.setSalvando();
    } catch (e) {
      this.TratarErro(e);
    }
  }

  salvarProcedimento(form: any) {
    try {
      this.carregando = true;
      if (
        !this.procedimento.id_primeiro_tipo_movimento &&
        !this.procedimento.id_procedimentos_cobranca_demaisdados &&
        !this.procedimento.duracao_prevista_cirurgia &&
        !this.procedimento.doenca_cid &&
        !this.procedimento.procedimento_compativel &&
        !this.procedimento.id_procedimento_cobranca
      ) {
        Util.AlertWarning(
          "Verifique se os campos de procedimento estão preenchidos antes de salvar!"
        );
        this.carregando = false;
        return;
      }

      this.procedimento = form.value;
      this.procedimentoSrv.salvarProcedimento(this.procedimento).subscribe({
        next: (r) => {
          if (r.success) {
            Util.AlertSucess("Procedimento salvo com sucesso!!");
            this.procedimento = new Procedimento();
            this.carregando = false;
          } else {
            Util.TratarErro(r.message);
          }
        },
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  salvarDemaisDados(form: any) {
    try {
      this.carregando = true;
      if (
        !this.procedimento.id_tipo_ato_medico &&
        !this.procedimento.id_fator_cobranca &&
        !this.procedimento.qtde_limite_uso &&
        !this.procedimento.id_tipo_tabela_procedimento_tiss
      ) {
        Util.AlertWarning(
          "Verifique se os campos de demais dados estão preenchidos antes de salvar!"
        );
        this.carregando = false;
        return;
      }

      this.demais_dados = form.value;
      this.procedimentoSrv.salvarDemaisDados(this.demais_dados).subscribe({
        next: (r) => {
          if (r.success) {
            Util.AlertSucess("Demais Dados salvo com sucesso!!");
            this.procedimento = new Procedimento();
            this.carregando = false;
          } else {
            Util.TratarErro(r.message);
          }
        },
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  salvarCobranca(form: any) {
    try {
      this.carregando = true;
      if (
        !this.procedimento.id_primeiro_tipo_movimento &&
        !this.procedimento.id_segundo_tipo_movimento &&
        !this.procedimento.id_terceiro_tipo_movimento
      ) {
        Util.AlertWarning(
          "Verifique se os campos de cobrança estão preenchidos antes de salvar!"
        );
        this.carregando = false;
        return;
      }

      this.cobranca = form.value;
      this.cobranca.id_colaborador =
        this.auth.getColaboradorLogado().id_colaborador;

      this.procedimentoSrv.salvarCobranca(this.cobranca).subscribe({
        next: (r) => {
          if (r.success) {
            Util.AlertSucess("Cobraça salvo com sucesso!!");
            this.procedimento = new Procedimento();
            this.carregando = false;
            this.ngOnChanges();
          } else {
            Util.TratarErro(r.message);
          }
        },
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  getCobranca() {
    try {
      this.carregando = true;
      let id_colaborador = this.auth.getColaboradorLogado().id_colaborador;
      this.procedimentoSrv.getCobranca(id_colaborador).subscribe({
        next: (r) => {
          if (r.success) {
            this.lista_diagnosticos = r.retorno;
            this.carregando = false;
          } else {
            Util.TratarErro(r.message);
          }
        },
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  salvarComposicao(form: any) {
    try {
      this.carregando = true;
      if (
        !this.procedimento.validade &&
        !this.procedimento.especificacao &&
        !this.procedimento.especialidade_basica_aih &&
        !this.procedimento.natureza_despesa_tiss &&
        !this.procedimento.duracao_cirurgia
      ) {
        Util.AlertWarning(
          "Verifique se os campos de composição estão preenchidos antes de salvar!"
        );
        this.carregando = false;
        return;
      }

      this.composicao = form.value;
      this.procedimentoSrv.salvarComposicao(this.composicao).subscribe({
        next: (r) => {
          if (r.success) {
            Util.AlertSucess("Composição salva com sucesso!!");
            this.procedimento = new Procedimento();
            this.carregando = false;
            this.ngOnChanges();
          } else {
            Util.TratarErro(r.message);
          }
        },
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  salvarDiagnosticos(form: any) {
    try {
      this.carregando = true;
      if (!this.procedimento.doenca_cid && !this.procedimento.qtde_permitida_diagnosticos) {
        Util.AlertWarning(
          "Verifique se os campos de diagnósticos estão preenchidos antes de salvar!"
        );
        this.carregando = false;
        return;
      }

      this.diagnosticos = form.value;
      this.diagnosticos.id_colaborador =
        this.auth.getColaboradorLogado().id_colaborador;
      this.procedimentoSrv.salvarDiagnosticos(this.diagnosticos).subscribe({
        next: (r) => {
          if (r.success) {
            Util.AlertSucess("Diagnosticos salvo com sucesso!!");
            this.procedimento = new Procedimento();
            this.carregando = false;
            this.ngOnChanges();
          } else {
            Util.TratarErro(r.message);
          }
        },
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  getDiagnosticos() {
    try {
      this.carregando = true;
      let id_colaborador = this.auth.getColaboradorLogado().id_colaborador;
      this.procedimentoSrv.getDiagnosticos(id_colaborador).subscribe({
        next: (r) => {
          if (r.success) {
            this.lista_diagnosticos = r.retorno;
            this.carregando = false;
          } else {
            Util.TratarErro(r.message);
          }
        },
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  salvarCompatibilidade(form: any) {
    try {
      this.carregando = true;
      if (
        !this.procedimento.procedimento_compativel &&
        !this.procedimento.qtde_permitida_compatibilidade
      ) {
        Util.AlertWarning(
          "Verifique se os campos de compatibilidade estão preenchidos antes de salvar!"
        );
        this.carregando = false;
        return;
      }

      this.compatibilidade = form.value;
      this.compatibilidade.id_colaborador =
        this.auth.getColaboradorLogado().id_colaborador;
      this.procedimentoSrv
        .salvarCompatibilidade(this.compatibilidade)
        .subscribe({
          next: (r) => {
            if (r.success) {
              Util.AlertSucess("Compatibilidade salvo com sucesso!!");
              this.procedimento = new Procedimento();
              this.carregando = false;
              this.ngOnChanges();
            } else {
              Util.TratarErro(r.message);
            }
          },
        });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  getCompatibilidade() {
    try {
      this.carregando = true;
      let id_colaborador = this.auth.getColaboradorLogado().id_colaborador;
      this.procedimentoSrv.getCompatibilidade(id_colaborador).subscribe({
        next: (r) => {
          if (r.success) {
            this.lista_compatibilidade = r.retorno;
            this.carregando = false;
          } else {
            Util.TratarErro(r.message);
          }
        },
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  salvarIncompatibilidade(form: any) {
    try {
      this.carregando = true;
      if (
        !this.procedimento.procedimento_incompativel &&
        !this.procedimento.qtde_permitida_incompatibilidade
      ) {
        Util.AlertWarning(
          "Verifique se os campos de incompatibilidade estão preenchidos antes de salvar!"
        );
        this.carregando = false;
        return;
      }

      this.incompatibilidade = form.value;
      this.incompatibilidade.id_colaborador =
        this.auth.getColaboradorLogado().id_colaborador;
      this.procedimentoSrv
        .salvarIncompatibilidade(this.incompatibilidade)
        .subscribe({
          next: (r) => {
            if (r.success) {
              Util.AlertSucess("Incompatibilidade salvo com sucesso!!");
              this.procedimento = new Procedimento();
              this.carregando = false;
              this.ngOnChanges();
            } else {
              Util.TratarErro(r.message);
            }
          },
        });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  getIncompatibilidade() {
    try {
      this.carregando = true;
      let id_colaborador = this.auth.getColaboradorLogado().id_colaborador;
      this.procedimentoSrv.getIncompatibilidade(id_colaborador).subscribe({
        next: (r) => {
          if (r.success) {
            this.lista_incompatibilidade = r.retorno;
            this.carregando = false;
          } else {
            Util.TratarErro(r.message);
          }
        },
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  salvarCbos(form: any) {
    try {
      this.carregando = true;
      if (
        !this.procedimento.cod_cbos_tiss &&
        !this.procedimento.compet_inicial &&
        !this.procedimento.qtde_permitida_cbos) {
        Util.AlertWarning(
          "Verifique se os campos de cbos estão preenchidos antes de salvar!"
        );
        this.carregando = false;
        return;
      }

      this.cbos = form.value;
      this.cbos.id_colaborador =
        this.auth.getColaboradorLogado().id_colaborador;
      this.procedimentoSrv.salvarCbos(this.cbos).subscribe({
        next: (r) => {
          if (r.success) {
            Util.AlertSucess("Cbos salvo com sucesso!!");
            this.procedimento = new Procedimento();
            this.carregando = false;
            this.ngOnChanges();
          } else {
            Util.TratarErro(r.message);
          }
        },
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  getCbos() {
    try {
      this.carregando = true;
      let id_colaborador = this.auth.getColaboradorLogado().id_colaborador;
      this.procedimentoSrv.getCbos(id_colaborador).subscribe({
        next: (r) => {
          if (r.success) {
            this.lista_cbos = r.retorno;
            this.carregando = false;
          } else {
            Util.TratarErro(r.message);
          }
        },
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }
}
