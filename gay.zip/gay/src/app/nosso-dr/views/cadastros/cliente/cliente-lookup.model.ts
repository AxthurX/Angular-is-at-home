import { LookupModel } from 'src/app/nosso-dr/core/components/lookup.component';
import { ILookup } from 'src/app/nosso-dr/core/interfaces/ilookup.i';
import { ClienteComponent } from './cliente.component';

export class ClienteLookup implements ILookup {
  constructor() {}
  onLimpar(): void {
    this.objeto_selecionado = new LookupModel();
  }
  objeto_selecionado: LookupModel;
  getComponent() {
    return ClienteComponent;
  }
}
