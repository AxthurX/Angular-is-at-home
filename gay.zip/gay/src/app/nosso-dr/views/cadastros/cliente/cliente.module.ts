import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ClienteComponent } from './cliente.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { NgxMaskModule } from 'ngx-mask';
import { SharedModule } from 'src/app/nosso-dr/core/shared.module';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ReactiveFormsModule } from '@angular/forms';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { QuillModule } from 'ngx-quill';
import { TermoConsentimentoComponent } from 'src/app/nosso-dr/core/components/termo-consentimento.component';

const routes: Routes = [
  {
    path: '',
    component: ClienteComponent,
  },
];

@NgModule({
  declarations: [ClienteComponent, TermoConsentimentoComponent],
  imports: [
    SharedModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes),
    NgSelectModule,
    NgxMaskModule.forRoot({ validation: true }), // Ngx-mask
    NgxDatatableModule,
    QuillModule,
  ],
  providers: [NgbActiveModal],
})
export class ClienteModule {}
