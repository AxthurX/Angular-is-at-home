export class Cliente {
  id: number;
  id_erp: number;
  sexo: string;
  email: string;
  razao: string;
  fantasia: string;
  cpf_cnpj: string;
  rg: string;
  cnh: string;
  limite_credito_disponivel: number;
  limite_credito: number;
  telefone_principal: string;
  telefone_whatsapp: string;
  cep: string;
  logradouro: string;
  numero: string;
  complemento: string;
  _data_nascimento: string;
  idade?: number;
  id_uf: number;
  id_municipio: number;
  id_bairro: number;

  prontuario_unico: number;
  nome_social: string;
  tipo_sanguineo?: string;
  situacao?: string;
  cns: string;
  nacionalidade: string;
  naturalidade: string;
  estado_civil: string;
  raca?: string;
  etnia_indigena?: string;
  grau_instrucao?: string;
  documento: string;
  numero_documento: string;
  certidao_nascimento?: string;
  nome_pai?: string;
  nome_mae?: string;
  religiao?: string;
  localizacao_prontuario?: string;
  nome_contato?: string;
  forma_contato: string;
  profissao?: string;
  local_trabalho?: string;
  convenio: number;
  nome_conjunge?: string;
  responsavel?: string;
  tipo_logradouro: string;
  municipioSelecionado: Municipio;
  bairroSelecionado: Bairro;
  ufSelecionada: UF;
}

export class Bairro {
  id: number;
  descricao: string;
  id_municipio: number;
  id_erp: number;
  id_banco_dados: number;
}

export class UF {
  id: number;
  descricao: string;
  sigla: string;
  codigo: string;
  id_pais: number;
  aliquota_icms_interna: number;
  aliquota_fcp_interna: number;
  dias_feriados_estaduais: number;
}

export class Municipio {
  id: number;
  id_uf: number;
  percentual: number;
  dias_feriados_municipais: number;
  descricao: string;
  codigo: string;
  zona_franca: boolean;
}
