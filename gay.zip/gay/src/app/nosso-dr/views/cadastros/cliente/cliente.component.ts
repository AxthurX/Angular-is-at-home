import { AuthService, DadosColaborador, DadosEmpresa, Medico } from "./../../../core/services/auth.service";
import { RetornoEndereco } from "./../../../core/services/cliente.service";
import { Component, ElementRef, OnInit, ViewChild } from "@angular/core";
import { NgbActiveModal, NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { ClasseBase } from "src/app/nosso-dr/core/model/classe-base.model";
import { ClienteService } from "src/app/nosso-dr/core/services/cliente.service";
import { Util } from "src/app/nosso-dr/core/util.model";
import { Bairro, Cliente, Municipio, UF } from "./cliente.model";
import { ColumnMode } from "@swimlane/ngx-datatable";
import { FirebaseService } from "src/app/nosso-dr/core/services/firebase.service";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Router } from "@angular/router";
import { TermoConsentimentoComponent } from "src/app/nosso-dr/core/components/termo-consentimento.component";
import { ProntuarioService } from "src/app/nosso-dr/core/services/prontuario.service";
import { AtendimentoService } from "src/app/nosso-dr/core/services/atendimento.service";
import { WhatsAppService } from "src/app/nosso-dr/core/services/whats-app.service";

@Component({
  selector: "app-cliente",
  templateUrl: "./cliente.component.html",
  styleUrls: ["./cliente.component.scss"],
})
export class ClienteComponent extends ClasseBase implements OnInit {
  @ViewChild("modalPrincipal", { static: true }) modalPrincipal: ElementRef;
  @ViewChild("modalProntuario", { static: true }) modalProntuario: ElementRef;
  @ViewChild("modalLgpd", { static: true }) modalLgpd: ElementRef;
  @ViewChild("modalUtils", { static: true }) modalUtils: ElementRef;

  formaInput: boolean;
  consultandoMunicipios: boolean;
  consultandoEndereco: boolean;
  consultandoBairros: boolean;
  cadastrando_bairro: boolean;
  bairro_descricao: string;

  consultando: boolean;
  enderecoConsultado: RetornoEndereco;
  ufs: UF[] = [];
  municipios: Municipio[] = [];
  bairros: Bairro[] = [];
  urls: string[] = [];
  nomes: string[] = [];

  ColumnMode = ColumnMode;
  loadingIndicator = true;
  reorderable = true;
  defaultNavActiveId = 1;
  navId: number;
  cliente: Cliente;
  clientes: Cliente[] = [];
  tipos_sexo = Util.GetTiposSexo();
  tipos_situacao = Util.GetTiposSituacao();
  documentos = Util.GetDocumentos();
  forma_contato = Util.GetFormaContato();
  medico_selecionado: Medico = this.auth.getMedicoSelecionado();
  dados_colaborador: DadosColaborador = this.auth.getColaboradorLogado();
  atendimentos_finalizados: any;
  base64: string;

  dia: number;
  mes: string;
  ano: number;
  historico: boolean = false;
  termo_aceito: boolean;
  detalhe_termo_consentimento: any;
  atendimento_selecionado: any;

  modelo_selecionado_anamnese: boolean = false;
  modelo_selecionado_avaliacao_plano: boolean = false;
  modelo_selecionado_prescricao: boolean = false;
  modelo_selecionado_orientacao: boolean = false;
  modelo_selecionado_atestado: boolean = false;
  id_prontuario_unico: number;
  constructor(
    public actModal: NgbActiveModal,
    private modal: NgbModal,
    private srv: ClienteService,
    private atendimentoSrv: AtendimentoService,
    private prontuarioSrv: ProntuarioService,
    private firebaseSrv: FirebaseService,
    private whatsSrv: WhatsAppService,
    private auth: AuthService,
    private rota: Router,
    private http: HttpClient
  ) {
    super();
    this.bairro_descricao = "";
    this.tentando_salvar = false;
    this.cadastrando_bairro = false;
    this.consultandoEndereco = false;
  }

  ngOnInit() {
    try {
      this.srv.getUf().subscribe((retorno) => {
        if (retorno.success) {
          this.ufs = retorno.retorno;
        } else {
          this.TratarErro(retorno.message);
        }
      });
      const data = new Date();
      this.dia = data.getDate();
      this.mes = data.toLocaleString("pt-br", { month: "long" });
      this.ano = data.getFullYear();
    } catch (e) {
      Util.TratarErro(e);
      this.consultando = false;
    }
  }

  setFocusDocumento() {
    try {
      setTimeout(() => {
        document.getElementById("prontuario_unico")?.focus();
      }, 500);
    } catch (e) {
      console.error("setFocusDocumento", e);
    }
  }

  override getTitulo(): string {
    return "Cadastro de pacientes";
  }

  override OnPesquisar(texto: string): void {
    try {
      this.carregando = true;
      this.srv.pesquisar(texto).subscribe({
        next: (r) => {
          this.carregando = false;
          if (r.success) {
            this.clientes = r.retorno;
          } else {
            this.TratarErro(r.message);
          }
        },
        error: (e) => this.TratarErro(e),
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  override OnCadastrar(): void {
    this.cliente = new Cliente();
    this.atendimentos_finalizados = null;
    this.openModal();
  }

  override OnEditar(objeto: any): void {
    this.cliente = new Cliente();
    this.cliente = objeto;
    this.openModal();
    this.PrencherDados(this.cliente);
  }

  override async OnSalvar() {
    this.tentando_salvar = true;

    if (!this.cliente.telefone_principal && !this.cliente.telefone_whatsapp) {
      this.tentando_salvar = false;
      Util.AlertWarning("Verifique se os campos de telefone estão preenchidos antes de salvar!");
      return;
    }

    if (!this.cliente.razao && !this.cliente.nome_contato && !this.cliente.nome_mae && !this.cliente.nome_pai) {
      this.tentando_salvar = false;
      Util.AlertWarning("Verifique se os campos de nome estão preenchidos antes de salvar!");
      return;
    }

    if (!this.cliente.municipioSelecionado) {
      this.tentando_salvar = false;
      Util.AlertWarning("Preencha o campo de município antes de salvar!");
      return;
    }

    if (!this.cliente.bairroSelecionado && !this.bairro_descricao) {
      this.tentando_salvar = false;
      Util.AlertWarning("Preencha o campo de bairro antes de salvar!");
      return;
    }

    if (!this.cliente.convenio && !this.cliente.cep && !this.cliente.sexo) {
      this.tentando_salvar = false;
      Util.AlertWarning("Ops, corrija os campos inválidos");
      return;
    }

    try {
      if (this.cadastrando_bairro && this.bairro_descricao) {
        this.cliente.bairroSelecionado = new Bairro();
        this.cliente.bairroSelecionado.id = 0;
        this.cliente.bairroSelecionado.id_banco_dados =
          this.auth.getEmpresaLogada().id_banco_dados;
        this.cliente.bairroSelecionado.id_municipio =
          this.cliente.municipioSelecionado?.id;
        this.cliente.bairroSelecionado.descricao =
          this.bairro_descricao.toUpperCase();
        const retorno = await this.srv
          .salvarBairro(
            this.cliente.municipioSelecionado?.id,
            this.cliente.bairroSelecionado.descricao.toUpperCase()
          )
          .toPromise();

        if (retorno?.success) {
          this.cliente.bairroSelecionado = retorno.retorno;
          this.bairro_descricao = this.cliente.bairroSelecionado.descricao;
          this.cliente.bairroSelecionado.id_municipio =
            this.cliente.municipioSelecionado.id;
          this.cliente.municipioSelecionado.id_uf =
            this.cliente.ufSelecionada.id;
        } else {
          Util.TratarErro(retorno?.message);
        }
      }

      this.cliente.id_uf = this.cliente.ufSelecionada.id;
      this.cliente.id_municipio = this.cliente.municipioSelecionado.id;
      this.cliente.id_bairro = this.cliente.bairroSelecionado?.id;
      this.setSalvando();
      this.srv.salvar(this.cliente).subscribe({
        next: (r) => {
          if (r.success) {
            this.clientes = r.retorno;
            this.Success("Paciente salvo com sucesso!");
            this.modal.dismissAll();
          } else {
            this.Error(r.message);
          }
        },
        error: (e) => this.TratarErro(e),
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  openModal() {
    this.modal.open(this.modalPrincipal, { size: "xl", centered: true });
    this.setFocusDocumento();
  }

  PrencherDados(cliente: Cliente) {
    this.srv.getUf().subscribe((ufs) => {
      this.ufs = ufs.retorno;
      const uf = this.ufs.find((c) => c.id === cliente.id_uf);
      if (uf) {
        this.cliente.ufSelecionada = uf;
      }
    });

    this.srv.getMunicipio(cliente?.id_uf).subscribe((municipios) => {
      this.municipios = municipios.retorno;
      const municipio = this.municipios.find(
        (c) => c.id === cliente.id_municipio
      );
      if (municipio) {
        this.cliente.municipioSelecionado = municipio;
      }
    });

    this.srv.getBairro(cliente?.id_municipio).subscribe((bairros) => {
      this.bairros = bairros.retorno;
      const bairro = this.bairros.find((c) => c.id === cliente.id_bairro);
      if (bairro) {
        this.cliente.bairroSelecionado = bairro;
      }
    });
  }

  onConsutarCEP() {
    try {
      //checo se ta valido
      if (this.cliente.cep && this.cliente.cep.length === 8 && navigator.onLine) {
        this.consultandoEndereco = true;
        this.srv.consultaCEP(this.cliente.cep).subscribe({
          next: (endereco) => {
            this.enderecoConsultado = endereco;
            if (endereco.erro) {
              Util.AlertWarning(
                "CEP não localizado, verifique se está correto!"
              );
              this.consultandoEndereco = false;
            } else {
              this.cliente.complemento = endereco.complemento.toUpperCase();
              this.cliente.logradouro = endereco.logradouro.toUpperCase();

              //consulto a uf
              const uf = this.ufs.find(
                (c) => c.sigla.toLocaleUpperCase() === endereco.uf.toUpperCase()
              );
              if (uf) {
                this.cliente.ufSelecionada = uf;
              }
              this.preencherMunicipios(this.cliente.ufSelecionada);
              this.consultandoEndereco = false;
            }
          },
        });
        (e: any) => {
          Util.TratarErro(e);
          this.consultandoEndereco = false;
        };
      }
    } catch (e) {
      Util.TratarErro(e);
      this.consultandoEndereco = false;
    }
  }

  onAlterouUF(ev: UF) {
    try {
      this.preencherMunicipios(ev);
    } catch (e) {
      Util.TratarErro(e);
    }
  }

  onAlterouBairro(ev: Bairro) {
    try {
      this.cliente.bairroSelecionado = ev;
    } catch (e) {
      Util.TratarErro(e);
    }
  }

  preencherMunicipios(uf: UF) {
    try {
      this.consultandoMunicipios = true;
      this.cliente.ufSelecionada = uf;
      this.bairros = [];
      this.municipios = [];

      this.srv
        .getMunicipio(this.cliente.ufSelecionada?.id as number)
        .subscribe((retorno2) => {
          this.municipios = retorno2.retorno;
          const ret = this.municipios.find(
            (c) =>
              c.codigo.toUpperCase() ===
              this.enderecoConsultado?.ibge?.toUpperCase()
          );
          if (ret) {
            this.cliente.municipioSelecionado = ret;
          }

          if (this.cliente.municipioSelecionado) {
            this.srv
              .getBairro(this.cliente.municipioSelecionado?.id as number)
              .subscribe((retorno) => {
                this.bairros = retorno.retorno;
                if (this.enderecoConsultado && !this.enderecoConsultado.bairro) {
                  //consultou um cep geral, n veio bairro, falo q é centro, foda-se
                  this.enderecoConsultado.bairro = "CENTRO";
                }
                const bairro = this.bairros.find(
                  (c) =>
                    c.descricao.toUpperCase() ===
                      this.enderecoConsultado?.bairro?.toUpperCase()
                );
                if (bairro) {
                  this.cliente.bairroSelecionado = bairro;
                }
                //consultou o cep mas n achou o bairro
                if (!this.cliente.bairroSelecionado && this.enderecoConsultado) {
                  this.bairro_descricao = this.enderecoConsultado.bairro;
                  this.cadastrando_bairro = true;
                }

                this.consultandoBairros = false;
              });
          }

          this.carregando = false;
        });
    } catch (e) {
      Util.TratarErro(e);
      this.consultandoMunicipios = false;
    }
  }

  onAlterouMunicipio(ev: Municipio) {
    try {
      this.consultandoBairros = true;
      this.cliente.municipioSelecionado = ev;
      this.bairros = [];
      this.srv
        .getBairro(this.cliente.municipioSelecionado?.id as number)
        .subscribe((retorno) => {
          this.bairros = retorno.retorno;

          if (this.enderecoConsultado && !this.enderecoConsultado.bairro) {
            //consultou um cep geral, n veio bairro, falo q é centro, foda-se
            this.enderecoConsultado.bairro = "CENTRO";
          }

          const bairro = this.bairros.find(
            (c) =>
              c.descricao.toUpperCase() ===
                this.enderecoConsultado?.bairro?.toUpperCase()
          );
          if (bairro) {
            this.cliente.bairroSelecionado = bairro;
          }
          this.bairro_descricao = "";
          this.cadastrando_bairro = false;

          //consultou o cep mas n achou o bairro
          if (!this.cliente.bairroSelecionado && this.enderecoConsultado) {
            this.bairro_descricao = this.enderecoConsultado.bairro;
            this.cadastrando_bairro = true;
          }

          this.consultandoBairros = false;
        });
    } catch (e) {
      Util.TratarErro(e);
      this.consultandoBairros = false;
    }
  }

  pegarProntuarios(registro: Cliente, modalProntuarios: boolean) {
    try {
      this.prontuarioSrv.getProntuario(registro.id).subscribe({
        next: (r) => {
          if (r.success) {
            this.atendimentos_finalizados = r.retorno;
            this.atendimentos_finalizados.paciente = registro.razao;
            this.atendimentos_finalizados.id_cliente = registro.id;
            this.atendimentos_finalizados.cpf = registro.cpf_cnpj;
            this.atendimentos_finalizados.email = registro.email;
            if (modalProntuarios === true) {
              this.modal.open(this.modalProntuario, { size: 'xl', centered: true });
            }
          } else {
            this.TratarErro(r.message);
          }
        },
        error: (e) => {
          this.TratarErro(e);
        },
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  pegarAtendimentos(id: number, item: any) {
    try {
      item.adicionando_modelo = !item.adicionando_modelo;
      this.atendimentoSrv.getAtendimentosById(id).subscribe({
        next: (r) => {
          if (r.success) {
            item.html = JSON.parse(r.retorno.json);
          } else {
            this.TratarErro(r.message);
          }
        },
        error: (e) => {
          this.TratarErro(e);
        },
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  modalUtilsProntuario(item: any, navId: number) {
    try {
      if (!item.adicionando_modelo) {
        Util.AlertWarning("Exibia o receituário que deseja fazer essa ação!");
        return;
      }

      this.atendimento_selecionado = item;
      this.navId = navId;
      this.modal.open(this.modalUtils, { size: "lg", centered: true });
    } catch (e) {
      Util.TratarErro(e);
    }
  }

  utilsProntuario(funcao: string) {
    this.consultando = true;
    try {
      if (this.modelo_selecionado_anamnese) {
        const anamnese = document.getElementById("anamnese")?.innerHTML;
        const nome = document.getElementById("nome_anamnese")?.innerHTML;
        const id = this.firebaseSrv.createId();
        const url = "https://obtersolucoes.nossoerp.com.br/nossoerpnuvem?id=" + id;
        if (nome) {
          this.nomes.push(nome);
          this.urls.push(url);
        }

        this.firebaseSrv
          .setHtmlImpressao(id,
          `
          <div class="container row">
            <p class="text-center text-dark fs-6 p-0 pt-2 mb-0 border-0">
              <b> Dr. ${this.atendimento_selecionado.medico} </b>
            </p>
            <p class="text-center text-dark fs-6 p-0 mb-0 border-0">
              <b> ${this.medico_selecionado.sigla_conselho} - ${this.medico_selecionado.numero_conselho}</b>
            </p>
            <p class="float-start fs-6 border-0" style="padding-top: 30px; padding-bottom:0; margin: 0;">
              <b>Nome do(a) paciente:</b> ${this.atendimento_selecionado.paciente}
            </p>
            <p class="float-start fs-6 border-0" style="padding-top: 0; padding-bottom: 40px; margin: 0;">
              <b>CPF:</b> ${this.atendimento_selecionado.cpf}
            </p>
          </div>
          ${anamnese}
            `
          )
          .then(() => {
            this.consultando = false;
            if (funcao === "imprimir") {
              window.open(
                url,
                "_blank",
                "toolbar=no,scrollbars=no,resizable=no,width=900,height=1000"
              );
            }

            if (funcao === "baixar" && nome) {
              this.downloadArquivo(url, nome);
            }
          });
      }

      if (this.modelo_selecionado_avaliacao_plano) {
        const avaliacao_plano = document.getElementById("avaliacao_plano")?.innerHTML;
        const nome = document.getElementById("nome_avaliacao_plano")?.innerHTML;
        const id = this.firebaseSrv.createId();
        const url = "https://obtersolucoes.nossoerp.com.br/nossoerpnuvem?id=" + id;
        if (nome) {
          this.nomes.push(nome);
          this.urls.push(url);
        }

        this.firebaseSrv
          .setHtmlImpressao(id,
          `
          <div class="container row">
            <p class="text-center text-dark fs-6 p-0 pt-2 mb-0 border-0">
              <b> Dr. ${this.atendimento_selecionado.medico} </b>
            </p>
            <p class="text-center text-dark fs-6 p-0 mb-0 border-0">
              <b> ${this.medico_selecionado.sigla_conselho} - ${this.medico_selecionado.numero_conselho}</b>
            </p>
            <p class="float-start fs-6 border-0" style="padding-top: 30px; padding-bottom:0; margin: 0;">
              <b>Nome do(a) paciente:</b> ${this.atendimento_selecionado.paciente}
            </p>
            <p class="float-start fs-6 border-0" style="padding-top: 0; padding-bottom: 40px; margin: 0;">
              <b>CPF:</b> ${this.atendimento_selecionado.cpf}
            </p>
          </div>
          ${avaliacao_plano}
          `
          )
          .then(() => {
            this.consultando = false;
            if (funcao === "imprimir") {
              window.open(
                url,
                "_blank",
                "toolbar=no,scrollbars=no,resizable=no,width=900,height=1000"
              );
            }

            if (funcao === "baixar" && nome) {
              this.downloadArquivo(url, nome);
            }
          });
      }

      if (this.modelo_selecionado_prescricao) {
        const prescricao = document.getElementById("prescricao")?.innerHTML;
        const nome = document.getElementById("nome_prescricao")?.innerHTML;
        const id = this.firebaseSrv.createId();
        const url = "https://obtersolucoes.nossoerp.com.br/nossoerpnuvem?id=" + id;
        if (nome) {
          this.nomes.push(nome);
          this.urls.push(url);
        }

        this.firebaseSrv
          .setHtmlImpressao(id,
          `
          <div class="container row">
            <p class="text-center text-dark fs-6 p-0 pt-2 mb-0 border-0">
              <b> Dr. ${this.atendimento_selecionado.medico} </b>
            </p>
            <p class="text-center text-dark fs-6 p-0 mb-0 border-0">
              <b> ${this.medico_selecionado.sigla_conselho} - ${this.medico_selecionado.numero_conselho}</b>
            </p>
            <p class="float-start fs-6 border-0" style="padding-top: 30px; padding-bottom:0; margin: 0;">
              <b>Nome do(a) paciente:</b> ${this.atendimento_selecionado.paciente}
            </p>
            <p class="float-start fs-6 border-0" style="padding-top: 0; padding-bottom: 40px; margin: 0;">
              <b>CPF:</b> ${this.atendimento_selecionado.cpf}
            </p>
          </div>
          ${prescricao}
            `
          )
          .then(() => {
            this.consultando = false;
            if (funcao === "imprimir") {
              window.open(
                url,
                "_blank",
                "toolbar=no,scrollbars=no,resizable=no,width=900,height=1000"
              );
            }

            if (funcao === "baixar" && nome) {
              this.downloadArquivo(url, nome);
            }
          });
      }

      if (this.modelo_selecionado_orientacao) {
        const orientacao = document.getElementById("orientacao")?.innerHTML;
        const nome = document.getElementById("nome_orientacao")?.innerHTML;
        const id = this.firebaseSrv.createId();
        const url = "https://obtersolucoes.nossoerp.com.br/nossoerpnuvem?id=" + id;
        if (nome) {
          this.nomes.push(nome);
          this.urls.push(url);
        }

        this.firebaseSrv
          .setHtmlImpressao(id,
          `
          <div class="container row">
            <p class="text-center text-dark fs-6 p-0 pt-2 mb-0 border-0">
              <b> Dr. ${this.atendimento_selecionado.medico} </b>
            </p>
            <p class="text-center text-dark fs-6 p-0 mb-0 border-0">
              <b> ${this.medico_selecionado.sigla_conselho} - ${this.medico_selecionado.numero_conselho}</b>
            </p>
            <p class="float-start fs-6 border-0" style="padding-top: 30px; padding-bottom:0; margin: 0;">
              <b>Nome do(a) paciente:</b> ${this.atendimento_selecionado.paciente}
            </p>
            <p class="float-start fs-6 border-0" style="padding-top: 0; padding-bottom: 40px; margin: 0;">
              <b>CPF:</b> ${this.atendimento_selecionado.cpf}
            </p>
          </div>
          ${orientacao}
          `
          )
          .then(() => {
            this.consultando = false;
            if (funcao === "imprimir") {
              window.open(
                url,
                "_blank",
                "toolbar=no,scrollbars=no,resizable=no,width=900,height=1000"
              );
            }

            if (funcao === "baixar" && nome) {
              this.downloadArquivo(url, nome);
            }
          });
      }

      if (this.modelo_selecionado_atestado) {
        const atestado = document.getElementById("atestado")?.innerHTML;
        const nome = document.getElementById("nome_atestado")?.innerHTML;
        const id = this.firebaseSrv.createId();
        const url = "https://obtersolucoes.nossoerp.com.br/nossoerpnuvem?id=" + id;
        if (nome) {
          this.nomes.push(nome);
          this.urls.push(url);
        }

        this.firebaseSrv
          .setHtmlImpressao(id,
          `
          <div class="container row">
            <p class="text-center text-dark fs-6 p-0 pt-2 mb-0 border-0">
              <b> Dr. ${this.atendimento_selecionado.medico} </b>
            </p>
            <p class="text-center text-dark fs-6 p-0 mb-0 border-0">
              <b> ${this.medico_selecionado.sigla_conselho} - ${this.medico_selecionado.numero_conselho}</b>
            </p>
            <p class="float-start fs-6 border-0" style="padding-top: 30px; padding-bottom:0; margin: 0;">
              <b>Nome do(a) paciente:</b> ${this.atendimento_selecionado.paciente}
            </p>
            <p class="float-start fs-6 border-0" style="padding-top: 0; padding-bottom: 40px; margin: 0;">
              <b>CPF:</b> ${this.atendimento_selecionado.cpf}
            </p>
          </div>
          ${atestado}
          `
          )
          .then(() => {
            this.consultando = false;
            if (funcao === "imprimir") {
              window.open(
                url,
                "_blank",
                "toolbar=no,scrollbars=no,resizable=no,width=900,height=1000"
              );
            }

            if (funcao === "baixar" && nome) {
              this.downloadArquivo(url, nome);
            }
          });
      }

      if (funcao === "email") {
        this.enviarEmail(this.atendimento_selecionado, this.urls, this.nomes);
      }

      if (funcao == "whatsapp") {
        this.carregando = true;
        const nomes = this.nomes.toString().split(",").join("\n");
        const urls = this.urls.toString().split(",").join("\n");
        this.whatsSrv
          .enviarMensagem(
            this.atendimento_selecionado.telefone,
            `Olá,

Segue abaixo a(s) copia(s) do receituário:

Receituário(s)
${nomes}

${urls}
        `
          )
          .subscribe({
            next: (r) => {
              this.carregando = false;
              if (!r.error) {
                Util.AlertSucess(
                  "Solicitação de mensagem enviada com sucesso! Confirme no aparelho se realmente a mensagem foi entregue ao paciente!"
                );
              } else if (r.error) {
                Util.AlertWarning(
                  "Verifique se você habilitou a integração com o whats app"
                );
              } else {
                this.TratarErro(r.message);
              }
            },
            error: (e) => this.TratarErro(e),
          });
      }
    } catch (e) {
      Util.TratarErro(e);
      this.limparDadosGerando();
      this.consultando = false;
    }
  }

  limparDadosGerando() {
    this.consultando = false;
    this.base64 = "";
  }

  enviarEmail(item: any, urls: any, nome: any) {
    try {
      if (!item.email) {
        Util.AlertWarning(`Não foi possivel localizar o e-mail para envio`);
      }

      this.carregando = true;
      this.prontuarioSrv.enviarEmail(item.id_cliente, urls, nome).subscribe({
        next: (r) => {
          if (r.success) {
            Util.AlertSucess(
              `enviado(a) com sucesso para o(s) e-mail(s) ${item.email}`
            );
            this.carregando = false;
          } else {
            Util.TratarErro(r.message);
          }
        },
      });
    } catch (e) {
      Util.TratarErro(e);
    }
  }

  downloadArquivo(url: string, nome: string) {
    try {
      this.download(url).subscribe((res) => {
        let url = window.URL.createObjectURL(res);
        let a = document.createElement("a");
        a.href = url;
        a.download = nome;
        a.click();
        window.URL.revokeObjectURL(url);
        a.remove();
      });
    } catch (e) {
      Util.TratarErro(e);
    }
  }

  download(url_impressao: string) {
    let url = url_impressao;
    let headers = new HttpHeaders();
    headers = headers.set("Aceept", "application/pdf");
    return this.http.get(url, { headers: headers, responseType: "blob" });
  }

  modalConsentimentoLgpd() {
    if (this.atendimentos_finalizados.length <= 0) {
      Util.AlertWarning(
        "Não foi possivel encontrar nenhum atendimento para enviar o termo de consentimento."
      );
      return;
    }

    if (!this.atendimentos_finalizados.email) {
      Util.AlertWarning(
        "Não foi possivel encontrar nenhum email para enviar o termo de consentimento."
      );
      return;
    }

    this.detalheTermoConsentimento();
    this.historico = this.termo_aceito =
      this.atendimentos_finalizados[0].consentimento_lgpd;
    this.modal.open(this.modalLgpd, { size: "lg", centered: true });
  }

  termoConsentimentoLgpd(funcao: string, atendimentos: any) {
    try {
      this.srv.getMunicipio(atendimentos[0].id_uf).subscribe((municipio) => {
        this.municipios = municipio.retorno;
        const municipios = this.municipios.find(
          (c) => c.id === atendimentos[0].id_municipio
        );
        if (municipios) {
          atendimentos.municipio = municipios.descricao;
        }

        const uf = this.ufs.find((c) => c.id === atendimentos[0].id_uf);
        if (uf) {
          atendimentos.uf = uf.sigla;
        }

        let content = TermoConsentimentoComponent.termo();
        content = content.replace(/\{{nome_paciente}}/g, atendimentos.paciente);
        content = content.replace(/\{{nome_clinica}}/g, this.auth.getEmpresaLogada().nome_colaborador);
        content = content.replace(/\{{cpf_paciente}}/g, atendimentos.cpf);
        content = content.replace(/\{{dia}}/g, this.dia.toString());
        content = content.replace(/\{{mes}}/g, this.mes);
        content = content.replace(/\{{ano}}/g, this.ano.toString());
        content = content.replace(/\{{municipio}}/g, atendimentos.municipio);
        content = content.replace(/\{{uf}}/g, atendimentos.uf);
        const id = this.firebaseSrv.createId();
        const url =
          "https://obtersolucoes.nossoerp.com.br/nossoerpnuvem?id=" + id;

        if (content) {
          this.firebaseSrv.setHtmlImpressao(id, content).then(
            () => {
              this.consultando = false;

              switch (funcao) {
                case "enviar":
                  try {
                    this.prontuarioSrv
                      .enviarEmailLGPD(
                        atendimentos.id_cliente,
                        atendimentos[0].id_agendamento
                      )
                      .subscribe({
                        next: (r) => {
                          if (r.success) {
                            Util.AlertSucess(
                              `enviado(a) com sucesso para o(s) e-mail(s) ${atendimentos.email}`
                            );
                            this.carregando = false;
                          } else {
                            Util.TratarErro(r.message);
                          }
                        },
                      });
                  } catch (e) {
                    Util.TratarErro(e);
                  }
                  break;
                case "imprimir":
                  window.open(
                    url,
                    "_blank",
                    "toolbar=no,scrollbars=no,resizable=no,width=900,height=1000"
                  );
                  break;
              }
            },
            (e) => {
              Util.TratarErro(e);
              this.limparDadosGerando();
              this.consultando = false;
            }
          );
        }
      });
    } catch (e) {
      Util.TratarErro(e);
      this.limparDadosGerando();
      this.consultando = false;
    }
  }

  async termoAssinado() {
    try {
      await Util.Confirm(
        `Deseja realmente marcar o termo como aceito?
        Essa ação não pode ser desfeita.`
      ).then((res) => {
        if (res.isConfirmed) {
          try {
            this.prontuarioSrv
              .confirmarTermoConsentimento(
                this.atendimentos_finalizados.id_cliente
              )
              .subscribe({
                next: (r) => {
                  if (r.success) {
                    Util.AlertSucess("Termo de Consentimento aceito com sucesso.");
                    setTimeout(() => {
                      this.detalheTermoConsentimento();
                    }, 200);
                  } else {
                    Util.TratarErro(r.message);
                  }
                },
              });
          } catch (e) {
            Util.TratarErro(e);
          }
        }
      });
    } catch (e) {
      Util.TratarErro(e);
    }
  }

  detalheTermoConsentimento() {
    try {
      this.prontuarioSrv
        .detalheTermoConsentimento(
          this.atendimentos_finalizados[0].id_agendamento
        )
        .subscribe({
          next: (r) => {
            if (r.success) {
              this.detalhe_termo_consentimento = r.retorno;
              if (this.detalhe_termo_consentimento.consentimento_lgpd) {
                this.historico =
                  this.detalhe_termo_consentimento.consentimento_lgpd;
              }
            }
          },
        });
    } catch (e) {
      Util.TratarErro(e);
    }
  }

  goTo(rota: any) {
    this.rota.navigate([rota]);
    this.modal.dismissAll();
  }

  prontuarioUnico(id_prontuario_unico: number) {
    try {
      if (id_prontuario_unico == null) {
        return;
      }

      this.prontuarioSrv.getProntuarioUnico(id_prontuario_unico).subscribe({
        next: (r) => {
          if (r.retorno == null) {
            Util.AlertWarning("Nenhum prontuário único foi encontrado");
            return;
          }

          if (r.success) {
            this.cliente = r.retorno;
            this.cliente.prontuario_unico = 0;
            this.cliente.id = 0;

            const uf = this.ufs.find((c) => c.id === this.cliente.id_uf);
            if (uf) {
              this.cliente.ufSelecionada = uf;
            }

            this.srv
              .getMunicipio(this.cliente?.id_uf)
              .subscribe((municipios) => {
                this.municipios = municipios.retorno;
                const municipio = this.municipios.find(
                  (c) => c.id === this.cliente.id_municipio
                );
                if (municipio) {
                  this.cliente.municipioSelecionado = municipio;
                }
              });

            this.srv
              .getBairro(this.cliente?.id_municipio)
              .subscribe((bairros) => {
                this.bairros = bairros.retorno;
                const bairro = this.bairros.find(
                  (c) => c.id === this.cliente.id_bairro
                );
                if (bairro) {
                  this.cliente.bairroSelecionado = bairro;
                }
              });
          } else {
            this.TratarErro(r.message);
          }
        },
        error: (e: any) => {
          this.TratarErro(e);
          Util.AlertError("Nenhum prontuário único foi encontrado");
        },
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }
}
