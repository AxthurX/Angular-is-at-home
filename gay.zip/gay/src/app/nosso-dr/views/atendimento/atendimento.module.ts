import { BtnClienteComponent } from './../../core/components/buttons/btn-cliente.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NgSelectModule } from '@ng-select/ng-select';
import { NgxMaskModule } from 'ngx-mask';
import { SharedModule } from '../../core/shared.module';
import { AtendimentoComponent } from './atendimento.component';
// ngx-quill
import { QuillModule } from 'ngx-quill';

const routes: Routes = [
  {
    path: '',
    component: AtendimentoComponent,
  },
];

@NgModule({
  declarations: [AtendimentoComponent, BtnClienteComponent],
  imports: [
    SharedModule,
    RouterModule.forChild(routes),
    NgSelectModule,
    NgxMaskModule.forRoot({ validation: true }), // Ngx-mask
    QuillModule,
  ],
})
export class AtendimentoModule {}
