import { Component, ElementRef, ViewChild, OnInit } from '@angular/core';
import { NgbCalendar, NgbDateStruct, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ClasseBase } from '../../core/model/classe-base.model';
import { AuthService } from '../../core/services/auth.service';
import { Util } from '../../core/util.model';
import { AtendimentoConsulta, AtendimentoModelJson } from './atendimento.model';
import { ModeloHtmlPronto } from './modelo-html-pronto.model';
import { Prescricao, Receituario } from './prescricao.model';
import { ClienteService, RetornoEndereco } from '../../core/services/cliente.service';
import { UF, Bairro, Municipio } from '../cadastros/cliente/cliente.model';
import { FirebaseService } from '../../core/services/firebase.service';
import { formatDate } from '@angular/common';
import { Agendamento } from '../agenda/agendamento.model';
import { TermoConsentimentoComponent } from '../../core/components/termo-consentimento.component';
import { AtendimentoService } from '../../core/services/atendimento.service';
import { ProntuarioService } from '../../core/services/prontuario.service';
import { ModelosService } from '../../core/services/modelos.service';

@Component({
  selector: 'app-atendimento',
  templateUrl: './atendimento.component.html',
  styleUrls: ['./atendimento.component.scss'],
})
export class AtendimentoComponent extends ClasseBase implements OnInit {
  @ViewChild('modalModelosProntos', { static: true }) modalModelosProntos: ElementRef;
  @ViewChild('modalImprimir', { static: true }) modalImprimir: ElementRef;
  @ViewChild('modalProntuario', {static: true}) modalProntuario: ElementRef;
  @ViewChild('modalLgpd', {static: true}) modalLgpd: ElementRef;
  sigla_conselho = this.auth.getMedicoSelecionado().sigla_conselho;
  periodos = Util.GetPeriodos();
  modelos_personalizado = new ModeloHtmlPronto();
  numero_periodo_prescicao: number = 1;
  id_periodo_prescicao_selecionado: number = 0;
  prescricao_preenchendo: Prescricao | undefined;
  modelos_anamnese: ModeloHtmlPronto[] = [];
  modelos_orientacao: ModeloHtmlPronto[] = [];
  modelos_atestado: ModeloHtmlPronto[] = [];
  modelos_formulas: ModeloHtmlPronto[] = [];
  modelos_selecionado: ModeloHtmlPronto[] = [];
  modelos_originais: ModeloHtmlPronto[] = [];
  modelos_personalizados: ModeloHtmlPronto[] = [];
  texto_html: string;
  modelo_enum: number;
  manter_tela_aberta: boolean = false;
  consultando_modelo: boolean = false;
  data_selecionada: NgbDateStruct;
  atendendo: AtendimentoConsulta;
  atendendo_modelo: AtendimentoModelJson;
  atendimentos: AtendimentoConsulta[] = [];
  consultando: boolean;
  submitted: boolean;
  ufs: UF[] = [];
  bairros: Bairro[] = [];
  municipios: Municipio[] = [];
  consultandoMunicipios: boolean;
  consultandoBairros: boolean;
  consultandoEndereco: boolean;
  enderecoConsultado: RetornoEndereco;
  atendimentos_finalizados: any;
  detalhe_termo_consentimento: any;
  modelo_impressao: string;
  base64: string;
  dia: number;
  mes: string;
  ano: number;
  historico?: boolean = false;
  termo_aceito?: boolean;
  quillConfig = {
    toolbar: {
      container: [
        ['bold', 'italic', 'underline', 'strike'], // toggled buttons
        ['code-block'],
        // [{ 'header': 1 }, { 'header': 2 }], // custom button values
        [{ list: 'ordered' }, { list: 'bullet' }],
        [{ script: 'sub' }, { script: 'super' }], // superscript/subscript
        [{ indent: '-1' }, { indent: '+1' }], // outdent/indent
        //  [{ 'direction': 'rtl' }], // text direction
        [{ size: ['small', false, 'large', 'huge'] }], // custom dropdown
        [{ header: [1, 2, 3, 4, 5, 6, false] }],
        [{ align: [] }],
        // ['clean'], // remove formatting button
        // ['link'],
        // ['link', 'image', 'video'],
      ],
    },
  };
  constructor(
    private calendar: NgbCalendar,
    private utilSrv: ClienteService,
    private atendimentoSrv: AtendimentoService,
    private modelosSrv: ModelosService,
    private prontuarioSrv: ProntuarioService,
    private auth: AuthService,
    private modal: NgbModal,
    private firebaseSrv: FirebaseService
  ) {
    super();
    this.submitted = false;
    this.consultandoEndereco = false;
    this.consultando = false;
  }

  override getTitulo(): string {
    return 'Atendimentos';
  }

  getSiglaConselho(): string {
    return 'Sigla do conselho';
  }

  setHoje() {
    this.data_selecionada = this.calendar.getToday();
    this.onConsultar();
  }

  setAmanha() {
    this.data_selecionada = this.calendar.getNext(
      this.calendar.getToday(),
      'd',
      1
    );
    this.onConsultar();
  }

  setOntem() {
    this.data_selecionada = this.calendar.getNext(
      this.calendar.getToday(),
      'd',
      -1
    );
    this.onConsultar();
  }

  ngOnInit(): void {
    setTimeout(() => {
      this.setHoje();
    }, 500);

    const data = new Date();
    this.dia = data.getDate();
    this.mes = data.toLocaleString("pt-br", { month: "long" });
    this.ano = data.getFullYear();
    try {
      this.consultando = true;
      this.utilSrv.getUf().subscribe((ufs) => {
        this.ufs = ufs.retorno;
        this.consultando = false;
      });
    } catch (e) {
      Util.TratarErro(e);
      this.consultando = false;
    }
  }

  ngOnDestroy() {
    if (window.history.state.modal) {
      history.back();
    }
  }

  onConsultar() {
    try {
      this.carregando = true;
      this.atendimentos = [];
      const data = Util.NgbDateStructToDate(this.data_selecionada, 0, 0);
      if (this.auth.getColaboradorLogado().tipo_usuario_nosso_dr == 1) {
        this.atendimentoSrv
          .getAtendimentos(
            this.auth.getMedicoSelecionado().id_usuario,
            this.auth.getEmpresaLogada().id_empresa_acessar,
            data,
            data
          )
          .subscribe({
            next: (retorno) => {
              if (retorno.success) {
                this.atendimentos = retorno.retorno;
              } else {
                this.TratarErro(retorno.message);
              }
              this.carregando = false;
            },
            error: (e) => {
              this.TratarErro(e);
            },
          });
      } else {
        this.atendimentoSrv
          .getAtendimentos(
            this.auth.getAtendenteSelecionado().id_usuario,
            this.auth.getEmpresaLogada().id_empresa_acessar,
            data,
            data
          )
          .subscribe({
            next: (retorno) => {
              if (retorno.success) {
                this.atendimentos = retorno.retorno;
              } else {
                this.TratarErro(retorno.message);
              }
              this.carregando = false;
            },
            error: (e) => {
              this.TratarErro(e);
            },
          });
      }
    } catch (e) {
      this.TratarErro(e);
    }
  }

  atender(atendimento: AtendimentoConsulta) {
    this.atendendo = atendimento;
    if (this.atendendo.atendimento.json) {
      this.atendendo_modelo = JSON.parse(this.atendendo.atendimento.json);
    } else {
      this.atendendo_modelo = new AtendimentoModelJson();
    }
  }

  override OnCancelar(): void {
    this.atendendo = null as any;
  }

  utilizarModeloPronto(modelo: number, prescricao_preenchendo?: Prescricao) {
    try {
      this.modelo_enum = modelo;
      this.consultando_modelo = true;
      this.prescricao_preenchendo = prescricao_preenchendo;
      this.modal.open(this.modalModelosProntos, { size: 'xl', centered: true });

      switch (this.modelo_enum) {
        case 0:
          if (this.modelos_anamnese.length == 0) {
            this.consultarModelos(this.modelos_anamnese);
          } else {
            this.modelos_originais = this.modelos_selecionado =
              this.modelos_anamnese;
            this.consultando_modelo = false;
          }
          break;
        case 1:
          if (this.modelos_orientacao.length == 0) {
            this.consultarModelos(this.modelos_orientacao);
          } else {
            this.modelos_originais = this.modelos_selecionado =
              this.modelos_orientacao;
            this.consultando_modelo = false;
          }
          break;
        case 2:
          if (this.modelos_atestado.length == 0) {
            this.consultarModelos(this.modelos_atestado);
          } else {
            this.modelos_originais = this.modelos_selecionado =
              this.modelos_atestado;
            this.consultando_modelo = false;
          }
          break;
        case 3:
          if (this.modelos_formulas.length == 0) {
            this.consultarModelos(this.modelos_formulas);
          } else {
            this.modelos_originais = this.modelos_selecionado =
              this.modelos_formulas;
            this.consultando_modelo = false;
          }
          break;
      }
    } catch (e) {
      this.TratarErro(e);
    }
  }

  async salvarModeloPersonalizado(
    modelo: number,
    prescricao_preenchendo?: Prescricao
  ) {
    this.carregando = true;
    try {
      this.setSalvando();
      this.modelo_enum = modelo;
      this.consultando_modelo = true;
      this.prescricao_preenchendo = prescricao_preenchendo;

      switch (this.modelo_enum) {
        case 0:
          if (this.atendendo_modelo.anamnese) {
            this.texto_html = this.atendendo_modelo.anamnese;
          } else {
            Util.AlertInfo('Para salvar informe um modelo personalizado válido');
            this.carregando = false;
          }
          break;
        case 1:
          if (this.atendendo_modelo.orientacao) {
            this.texto_html = this.atendendo_modelo.orientacao;
          } else {
            Util.AlertInfo('Para salvar informe um modelo personalizado válido');
            this.carregando = false;
          }
          break;
        case 2:
          if (this.atendendo_modelo.atestado) {
            this.texto_html = this.atendendo_modelo.atestado;
          } else {
            Util.AlertInfo('Para salvar informe um modelo personalizado válido');
            this.carregando = false;
          }
          break;
        case 3:
          if (this.prescricao_preenchendo?.html) {
            this.texto_html = this.prescricao_preenchendo.html;
          } else {
            Util.AlertInfo('Para salvar informe um modelo personalizado válido');
            this.carregando = false;
          }
          break;
      }

      if (this.texto_html && this.texto_html !== '' && (this.atendendo_modelo || this.prescricao_preenchendo?.html)) {
        const descricao = await Util.EspecificarTexto(
          'Digite uma descrição',
          'Digite uma descrição para o modelo personalizado',
          'text',
          ''
        );

        if (descricao.isConfirmed) {
          await Util.Confirm(
            `Salvando o modelo: "<b>${descricao.value}</b>"`
          ).then((res) => {
            if (res.isConfirmed) {
              this.modelos_personalizado.descricao = descricao.value;
              this.modelos_personalizado.html = this.texto_html;
              this.modelos_personalizado.modelo = modelo;

              this.modelosSrv
                .setModeloPersonalizados(this.modelos_personalizado)
                .subscribe({
                  next: (r) => {
                    this.carregando = false;
                    if (r.success) {
                      this.modelos_personalizados = r.retorno;
                      this.Success("Modelo personalizado salvo com sucesso");
                      this.texto_html = "";
                    } else {
                      this.Error(r.message);
                    }
                  },
                  error: (e) => {
                    this.TratarErro(e);
                  },
                });
            } else {
              this.carregando = false;
              this.texto_html = "";
            }
          });
        } else {
          this.carregando = false;
          this.texto_html = "";
        }
      }
    } catch (e) {
      Util.AlertErrorPadrao();
    }
  }

  consultarModelos(modelos: ModeloHtmlPronto[]) {
    try {
      this.modelosSrv.getAllModelosHtmlPronto(this.modelo_enum).subscribe({
        next: (r) => {
          if (r.success) {
            modelos = r.retorno;
            this.modelos_originais = this.modelos_selecionado = modelos;
          } else {
            this.TratarErro(r.message);
          }

          this.consultando_modelo = false;
        },
        error: (e) => {
          this.consultando_modelo = false;
        },
      });
    } catch (e) {
      this.consultando_modelo = false;
      this.TratarErro(e);
    }
  }

  setModeloSelecionado(modelo: ModeloHtmlPronto) {
    try {
      modelo.adicionando = true;
      this.modelosSrv.getModeloHtmlPronto(modelo.id).subscribe({
        next: (r) => {
          if (r.success) {
            let html = r.retorno.html;
            const data_atual = formatDate(new Date(), "dd/MM/yyyy", "pt-BR");
            html = html.replace(/\{{patient_name}}/g, this.atendendo.agendamento.paciente);
            html = html.replace(/\{{doctor_name}}/g, this.auth.getEmpresaLogada().nome_colaborador);
            html = html.replace(/{{\s*current_date_day\s*}}\/{{\s*current_date_month\s*}}\/{{\s*current_date_year\s*}}/g, data_atual);

            switch (this.modelo_enum) {
              case 0:
                if (this.atendendo_modelo.anamnese) {
                  this.atendendo_modelo.anamnese =
                    this.atendendo_modelo.anamnese.concat("<br/><br/>", html);
                } else {
                  this.atendendo_modelo.anamnese = html;
                }
                break;
              case 1:
                if (this.atendendo_modelo.orientacao) {
                  this.atendendo_modelo.orientacao =
                    this.atendendo_modelo.orientacao.concat("<br/><br/>", html);
                } else {
                  this.atendendo_modelo.orientacao = html;
                }
                break;
              case 2:
                if (this.atendendo_modelo.atestado) {
                  this.atendendo_modelo.atestado =
                    this.atendendo_modelo.atestado.concat("<br/><br/>", html);
                } else {
                  this.atendendo_modelo.atestado = html;
                }
                break;
              case 3:
                if (this.prescricao_preenchendo) {
                  if (this.prescricao_preenchendo.html) {
                    this.prescricao_preenchendo.html =
                      this.prescricao_preenchendo.html.concat(
                        "<br/><br/>",
                        html
                      );
                  } else {
                    this.prescricao_preenchendo.html = html;
                  }
                }
                break;
            }
            modelo.adicionado = true;
            if (!this.manter_tela_aberta) {
              this.modal.dismissAll();
            } else {
              Util.NotificacaoInfo("Modelo adicionado...");
            }
          } else {
            this.TratarErro(r.message);
          }
          modelo.adicionando = false;
        },
        error: (e) => {
          modelo.adicionando = false;
          this.TratarErro(e);
        },
      });
    } catch (e) {
      modelo.adicionando = false;
      this.TratarErro(e);
    }
  }

  async onFinalizar() {
    try {
      const result = await Util.Confirm("Finalizando atendimento");
      if (!result.isConfirmed) {
        return;
      }

      const timezone_ms = new Date().getTimezoneOffset() * 60000;
      const data_hora = new Date(Date.now() - timezone_ms)
        .toISOString()
        .slice(0, -1);

      this.atendendo.atendimento.data_hora = data_hora;
      this.atendendo.atendimento.usuario = this.auth.getColaboradorLogado().nome.trim();
      this.atendendo.atendimento.finalizado = true;
      this.OnSalvar();
    } catch (e) {
      this.TratarErro(e);
    }
  }

  override async OnSalvar() {
    this.submitted = true;
    try {
      this.carregando = true;
      if (this.atendendo_modelo.prescricoes) {
        //salvo so o q tiver preenchido
        this.atendendo_modelo.prescricoes =
          this.atendendo_modelo.prescricoes.filter((c) => c.html?.length > 0);

        const controle_especial = this.atendendo_modelo.prescricoes.every(
          (c) => c.controle_especial === true
        );

        for (const prescricao of this.atendendo_modelo.prescricoes) {
          if (controle_especial && !prescricao.receituario.municipioSelecionado) {
            Util.AlertWarning("Preencha o campo de município antes de salvar!");
            this.carregando = false;
            return;
          }

          if (controle_especial && !prescricao.receituario.bairroSelecionado) {
            Util.AlertWarning("Preencha o campo de bairro antes de salvar!");
            this.carregando = false;
            return;
          }

          if (controle_especial && (!prescricao.receituario.nome || !prescricao.receituario.cep || !prescricao.receituario.telefone)) {
            Util.AlertWarning('Ops, corrija os campos inválidos');
            this.carregando = false;
            return;
          }

          if (prescricao.receituario.bairroSelecionado?.id === -1) {
            const retorno = await this.utilSrv
              .salvarBairro(
                prescricao.receituario.bairroSelecionado?.id_municipio,
                prescricao.receituario.bairroSelecionado.descricao.toUpperCase()
              )
              .toPromise();
            if (retorno?.success) {
              prescricao.receituario.bairroSelecionado.id = retorno.retorno.id;
            } else {
              Util.TratarErro(retorno?.message);
              return;
            }
          }
        }
      }

      this.atendendo.atendimento.json = JSON.stringify(this.atendendo_modelo);
      this.atendimentoSrv.setAtendimento(this.atendendo.atendimento).subscribe({
        next: (r) => {
          this.carregando = false;
          if (r.success) {
            this.atendendo.atendimento.id = r.retorno.id;
            this.Success("Atedimento salvo com sucesso!");
            this.OnCancelar();
          } else {
            this.TratarErro(r.message);
          }
        },
        error: (e) => {
          this.TratarErro(e);
        },
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  override OnPesquisar(texto: string): void {
    try {
      if (texto) {
        this.modelos_selecionado = this.modelos_originais.filter(
          (c) => c.descricao.toUpperCase().indexOf(texto.toUpperCase()) > -1
        );
      } else {
        this.modelos_selecionado = this.modelos_originais;
      }
    } catch (e) {
      this.TratarErro(e);
    }
  }

  async removerNovaPrescricao(i: number) {
    try {
      if (!this.atendendo_modelo.prescricoes) {
        this.atendendo_modelo.prescricoes = [];
      }
      await Util.Confirm(`Deseja excluir essa prescrição`).then((res) => {
        if (res.isConfirmed) {
          this.atendendo_modelo.prescricoes.splice(i, 1);
        }
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  addNovaPrescricao() {
    try {
      if (!this.atendendo_modelo.prescricoes) {
        this.atendendo_modelo.prescricoes = [];
      }

      const receituario = new Receituario();
      this.atendendo_modelo.prescricoes.push({
        controle_especial: false,
        html: "",
        receituario: receituario,
      });

      // adicionando o numero e a uf do conselho no receituario de controle especial
      this.atendendo_modelo.prescricoes.forEach((v) => {
        v.receituario.numero_conselho =
          this.auth.getMedicoSelecionado().numero_conselho;
        const uf = this.ufs.find(
          (c) => c.id === this.auth.getMedicoSelecionado().id_uf_conselho
        );
        if (uf) {
          v.receituario.uf_conselho = uf;
        } else {
          Util.AlertWarning(
            "A Uf do conselho não foi localizada, tente configurar na aba de configurações"
          );
        }
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  addAPrescricao(p: Prescricao) {
    if (!p.html) {
      p.html = "";
    }

    p.html += `<br/><br/>Receita válida por ${this.numero_periodo_prescicao} ${
      this.periodos.find((c) => c.id === this.id_periodo_prescicao_selecionado)
        ?.descricao
    }`;
  }

  onAlterouUF(receituario: Receituario) {
    try {
      this.preencherMunicipios(receituario);
    } catch (e) {
      Util.TratarErro(e);
    }
  }

  preencherMunicipios(receituario: Receituario) {
    try {
      this.consultandoMunicipios = true;
      receituario.ufSelecionada = receituario.ufSelecionada;
      this.bairros = [];
      this.municipios = [];
      receituario.bairroSelecionado;
      receituario.municipioSelecionado;
      this.utilSrv
        .getMunicipio(receituario.ufSelecionada.id)
        .subscribe((municipio) => {
          this.municipios = municipio.retorno;
          const ret = this.municipios.find(
            (c) =>
              c.codigo.toUpperCase() ===
                this.enderecoConsultado?.ibge?.toUpperCase()
          );
          if (ret) {
            receituario.municipioSelecionado = ret;
          }
          if (receituario.municipioSelecionado) {
            this.utilSrv
              .getBairro(receituario.municipioSelecionado?.id)
              .subscribe((bairros) => {
                this.bairros = bairros.retorno;
                if (this.enderecoConsultado && !this.enderecoConsultado.bairro) {
                  //consultou um cep geral, n veio bairro, falo q é centro, foda-se
                  this.enderecoConsultado.bairro = "CENTRO";
                }
                const bairro = this.bairros.find(
                  (c) =>
                    c.descricao.toUpperCase() ===
                    this.enderecoConsultado?.bairro?.toUpperCase()
                );

                if (bairro) {
                  receituario.bairroSelecionado = bairro;
                } else {
                  const novo_bairro = new Bairro();
                  novo_bairro.id = -1;
                  novo_bairro.id_municipio =
                    receituario.municipioSelecionado.id;
                  novo_bairro.descricao =
                    this.enderecoConsultado.bairro.toUpperCase();
                  novo_bairro.id_banco_dados =
                    this.auth.getEmpresaLogada().id_banco_dados;
                  receituario.bairroSelecionado = novo_bairro;
                  this.bairros.push(novo_bairro);
                }
                this.consultandoBairros = false;
              });
          }
          this.consultandoMunicipios = false;
        });
    } catch (e) {
      Util.TratarErro(e);
      this.consultandoMunicipios = false;
    }
  }

  onAlterouMunicipio(receituario: Receituario) {
    try {
      this.consultandoBairros = true;
      this.bairros = [];
      this.utilSrv
        .getBairro(receituario.municipioSelecionado?.id)
        .subscribe((bairros) => {
          this.bairros = bairros.retorno;
          if (this.enderecoConsultado && !this.enderecoConsultado.bairro) {
            //consultou um cep geral, n veio bairro, falo q é centro, foda-se
            this.enderecoConsultado.bairro = "CENTRO";
          }
          const bairro = this.bairros.find(
            (c) =>
              c.descricao.toUpperCase() ===
              this.enderecoConsultado?.bairro?.toUpperCase()
          );
          if (bairro) {
            receituario.bairroSelecionado = bairro;
          }
          this.consultandoBairros = false;
        });
    } catch (e) {
      Util.TratarErro(e);
      this.consultandoBairros = false;
    }
  }

  // onAlterouBairro(ev: Receituario) {
  //   try {
  //     this.receituario.bairroSelecionado = ev;
  //   } catch (e) {
  //     Util.TratarErro(e);
  //   }
  // }

  onConsutarCEP(receituario: Receituario) {
    try {
      //checo se ta valido
      if (receituario.cep && receituario.cep.length === 8 && navigator.onLine) {
        this.consultandoEndereco = true;
        this.utilSrv.consultaCEP(receituario.cep).subscribe({
          next: (endereco) => {
            this.enderecoConsultado = endereco;
            if (endereco.erro) {
              Util.AlertWarning(
                "CEP não localizado, verifique se está correto!"
              );
              this.consultandoEndereco = false;
            } else {
              receituario.complemento = endereco.complemento;
              receituario.logradouro = endereco.logradouro;

              //consulto a uf
              const uf = this.ufs.find(
                (c) => c.sigla.toLocaleUpperCase() === endereco.uf.toUpperCase()
              );
              if (uf) {
                receituario.ufSelecionada = uf;
              }
              this.preencherMunicipios(receituario);
              this.consultandoEndereco = false;
              this.consultandoMunicipios = false;
            }
          },
        }),
          (e: any) => {
            Util.TratarErro(e);
            this.consultandoEndereco = false;
          };
      }
    } catch (e) {
      Util.TratarErro(e);
      this.consultandoEndereco = false;
    }
  }

  downloadPdf(modelo: number, prescricao_preenchendo?: Prescricao) {
    this.modal.open(this.modalImprimir, { size: "lg", centered: true });
    this.modelo_enum = modelo;
    this.prescricao_preenchendo = prescricao_preenchendo;
    this.consultando = true;
    setTimeout(() => {
      try {
        switch (this.modelo_enum) {
          case 0:
            if (this.atendendo_modelo.anamnese) {
              this.modelo_impressao = this.atendendo_modelo.anamnese;
            }
            break;
          case 1:
            if (this.atendendo_modelo.orientacao) {
              this.modelo_impressao = this.atendendo_modelo.orientacao;
            }
            break;
          case 2:
            if (this.atendendo_modelo.atestado) {
              this.modelo_impressao = this.atendendo_modelo.atestado;
            }
            break;
          case 3:
            if (this.prescricao_preenchendo?.html) {
              this.modelo_impressao = this.prescricao_preenchendo.html;
            }
            break;
        }

        setTimeout(() => {
          this.gerarPdf();
          this.modal.dismissAll();
        }, 500);
      } catch (e) {
        Util.TratarErro(e);
        this.consultando = false;
      }
    }, 400);
  }

  gerarPdf() {
    this.consultando = true;
    try {
      const content = document.getElementById("imprimir")?.innerHTML;
      const id = this.firebaseSrv.createId();
      if (content) {
        this.firebaseSrv.setHtmlImpressao(id, content).then(
          () => {
            this.consultando = false;
            window.open(
              "https://obtersolucoes.nossoerp.com.br/nossoerpnuvem?id=" + id,
              "_blank",
              "toolbar=no,scrollbars=no,resizable=no,width=900,height=1000"
            );
          },
          (e) => {
            Util.TratarErro(e);
            this.limparDadosGerando();
            this.consultando = false;
          }
        );
      }
    } catch (e) {
      Util.TratarErro(e);
      this.limparDadosGerando();
      this.consultando = false;
    }
  }

  limparDadosGerando() {
    this.consultando = false;
    this.base64 = "";
  }

  pegarProntuarios(registro: Agendamento) {
    try {
      this.prontuarioSrv.getProntuario(registro.id_cliente).subscribe({
        next: (r) => {
          if (r.success) {
            this.atendimentos_finalizados = r.retorno;
            this.atendimentos_finalizados.id_cliente = registro.id;
            this.atendimentos_finalizados.paciente = registro.paciente;
            this.modal.open(this.modalProntuario, { size: 'lg', centered: true });
          } else {
            this.TratarErro(r.message);
          }
        },
        error: (e) => {
          this.TratarErro(e);
        },
      });
    } catch (e) {
      this.TratarErro(e);
    }
  }

  pegarAtendimentos(id: number, item: any) {
    try {
      item.adicionando_modelo = !item.adicionando_modelo;
      this.atendimentoSrv.getAtendimentosById(id).subscribe({
        next: (r) => {
          if (r.success) {
            item.html = JSON.parse(r.retorno.json);
            this.atendendo.atendimento.json = JSON.stringify(item.html);
          } else {
            Util.TratarErro(r.message);
          }
        },
        error: (e) => {
          Util.TratarErro(e);
        },
      });
    } catch (e) {
      Util.TratarErro(e);
    }
  }

  importarAtendimento(item: any) {
    this.atendimentoSrv.getAtendimentosById(item.id_atendimento).subscribe({
      next: (model) => {
        if (model.success) {
          this.prontuarioSrv.replicarAtendimento(item.id_cliente).subscribe({
            next: (r) => {
              if (r.success) {
                let atendimento: AtendimentoConsulta = r.retorno;
                let id_agendamento = this.atendendo.atendimento.id_agendamento;
                this.atendendo = atendimento;
                this.atendendo.atendimento.id_agendamento = id_agendamento;
                this.atendendo_modelo = item.html = JSON.parse(model.retorno.json);
                this.modal.dismissAll();
              }
            },
            error: (e) => {
              this.TratarErro(e);
            },
          });
        }
      },
      error: (e) => {
        this.TratarErro(e);
      },
    });
  }

  modalConsentimentoLgpd() {
    if (!this.atendendo.agendamento.email) {
      Util.AlertWarning(
        "Não foi possivel encontrar nenhum email para enviar o termo de consentimento."
      );
      return;
    }

    this.historico = this.termo_aceito =
      this.atendendo.agendamento.consentimento_lgpd;
    this.detalhesTermoConsentimento();
    this.modal.open(this.modalLgpd, { size: "lg", centered: true });
  }

  termoConsentimentoLgpd(funcao: string) {
    try {
      let content = TermoConsentimentoComponent.termo();
      content = content.replace(/\{{nome_paciente}}/g, this.atendendo.agendamento.paciente);
      content = content.replace(/\{{nome_clinica}}/g, this.auth.getEmpresaLogada().nome_colaborador);
      content = content.replace(/\{{cpf_paciente}}/g, this.atendendo.agendamento.cpf_cnpj);
      content = content.replace(/\{{dia}}/g, this.dia.toString());
      content = content.replace(/\{{mes}}/g, this.mes);
      content = content.replace(/\{{ano}}/g, this.ano.toString());
      content = content.replace(/\{{municipio}}/g, "Porto velho");
      content = content.replace(/\{{uf}}/g, "RO");
      const id = this.firebaseSrv.createId();
      const url = "https://obtersolucoes.nossoerp.com.br/nossoerpnuvem?id=" + id;

      if (content) {
        this.firebaseSrv.setHtmlImpressao(id, content).then(
          () => {
            this.consultando = false;
            switch (funcao) {
              case "enviar":
                try {
                  if (!this.atendendo.agendamento.email) {
                    Util.AlertWarning(
                      `Não foi possivel localizar o e-mail para envio do termo de consentimento lgpd`
                    );
                  }

                  this.prontuarioSrv
                    .enviarEmailLGPD(
                      this.atendendo.agendamento.id_cliente,
                      this.atendendo.atendimento.id_agendamento
                    )
                    .subscribe({
                      next: (r) => {
                        if (r.success) {
                          Util.AlertSucess(
                            `enviado(a) com sucesso para o(s) e-mail(s) ${this.atendendo.agendamento.email}`
                          );
                          this.carregando = false;
                        } else {
                          Util.TratarErro(r.message);
                        }
                      },
                    });
                } catch (e) {
                  Util.TratarErro(e);
                }
                break;

              case "imprimir":
                window.open(
                  url,
                  "_blank",
                  "toolbar=no,scrollbars=no,resizable=no,width=900,height=1000"
                );
                break;
            }
          },
          (e) => {
            Util.TratarErro(e);
            this.limparDadosGerando();
            this.consultando = false;
          }
        );
      }
    } catch (e) {
      Util.TratarErro(e);
      this.limparDadosGerando();
      this.consultando = false;
    }
  }

  async termoAssinado() {
    try {
      await Util.Confirm(
        `Deseja realmente marcar o termo como aceito?
        Essa ação não pode ser desfeita.`
      ).then((res) => {
        if (res.isConfirmed) {
          try {
            this.prontuarioSrv
              .confirmarTermoConsentimento(this.atendendo.agendamento.id)
              .subscribe({
                next: (r) => {
                  if (r.success) {
                    Util.AlertSucess(
                      "Termo de Consentimento aceito com sucesso."
                    );
                    setTimeout(() => {
                      this.detalhesTermoConsentimento();
                    }, 200);
                  } else {
                    Util.TratarErro(r.message);
                  }
                },
              });
          } catch (e) {
            Util.TratarErro(e);
          }
        }
      });
    } catch (e) {
      Util.TratarErro(e);
    }
  }

  detalhesTermoConsentimento() {
    try {
      this.prontuarioSrv
        .detalheTermoConsentimento(this.atendendo.atendimento.id_agendamento)
        .subscribe({
          next: (r) => {
            if (r.success) {
              this.detalhe_termo_consentimento = r.retorno;
              if (this.detalhe_termo_consentimento.consentimento_lgpd) {
                this.atendendo.agendamento.consentimento_lgpd =
                  this.detalhe_termo_consentimento.consentimento_lgpd;

                this.historico = this.termo_aceito =
                  this.detalhe_termo_consentimento.consentimento_lgpd;
              }
            }
          },
        });
    } catch (e) {
      Util.TratarErro(e);
    }
  }
}
