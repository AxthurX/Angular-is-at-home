import { UF, Municipio, Bairro } from '../cadastros/cliente/cliente.model';

export class Prescricao {
  controle_especial: boolean = false;
  html: string = '';
  receituario: Receituario;
}

export class Receituario {
  nome: string;
  telefone: string;
  uf_conselho: UF;
  sigla_conselho: number;
  numero_conselho: string;
  cep: string;
  logradouro: string;
  bairro: string;
  numero: string;
  complemento: string;
  ufSelecionada: UF;
  municipioSelecionado: Municipio;
  bairroSelecionado: Bairro;
}
