export class ModeloHtmlPronto {
  id: number;
  descricao: string;
  html: string;
  indices: string;
  modelo?: number;
  do_sistema: boolean;
  adicionado: boolean = false;
  adicionando: boolean = false;
}
