import { Agendamento } from '../agenda/agendamento.model';
import { Prescricao } from './prescricao.model';

export class Atendimento {
  id: number;
  id_agendamento: number;
  json: string;
  finalizado: boolean;
  data_hora: string;
  usuario: string;
}

export class AtendimentoModelJson {
  anamnese: string = '';
  avaliacao_plano: string = '';
  prescricoes: Prescricao[] = [];
  orientacao: string = '';
  atestado: string = '';
}

export class AtendimentoConsulta {
  atendimento: Atendimento;
  agendamento: Agendamento;
}
