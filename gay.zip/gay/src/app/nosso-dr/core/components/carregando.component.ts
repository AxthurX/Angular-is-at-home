import { Component } from '@angular/core';

@Component({
  selector: 'app-carregando',
  template: `<div class="d-flex justify-content-center">
    <img src="/assets/images/load.gif" />
  </div>`,
})
export class CarregandoComponent {
  constructor() {}
}
