export interface MyFile {
  filename: string;
  type: string;
  size: number;
  date: number;
  path: string;
  id?: string;
  url_completa: string;
  usuario: string;
}
