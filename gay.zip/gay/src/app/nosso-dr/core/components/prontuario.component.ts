import { Component, Input, Output, EventEmitter } from '@angular/core';
import { ClasseBase } from '../model/classe-base.model';
import { TipoIcone } from './icone.component';

@Component({
  selector: 'app-prontuario',
  template: `
      <button type="button" class="btn btn-icon-text btn-sm pt-0">
        <img style="margin-right: 4px; width: {{ width }}px; height: {{ heigth }}px;" src="assets/icones/{{ icone }}.png">
        <p *ngIf="nome" class="text-white mx-1 fs-5 text-center align-self-end">Importar</p>
      </button>
      `,
})
export class ProntuarioComponent {
  @Input() parent: ClasseBase;
  @Input() objeto: any;
  @Input() icone?: TipoIcone;
  @Input() width: number = 24;
  @Input() heigth: number = 24;
  @Input() nome?: boolean = false
  @Output() click: EventEmitter<any> = new EventEmitter();
  constructor() {}
}
