import { Component } from '@angular/core';

@Component({
  selector: 'app-termo-consentimento',
  template: ``,
})

export class TermoConsentimentoComponent {
  
  static termo() {
    return `
<div width="100%" style="border-spacing:0px;">
  <div width="100%" style="border-collapse:collapse;border-spacing:0px;">
    <div align="center" style="margin:0;padding-left:10px;padding-right:10px;padding-bottom:15px;padding-top:0;">
      <div style="border-color: transparent; border-width: 0px; border-radius: 5px; text-decoration: none; font-family: 'open sans', 'helvetica neue', helvetica, arial, sans-serif; font-size: 18px; border-radius: 5px; font-weight: normal; font-style: normal; line-height: 20px; text-align: justify; text-indent: 40px; padding-bottom: 2.5rem;">
        <p style="text-align: center; border: 2px solid black; text-indent: 0; padding-bottom: .2rem; padding-top: .2rem;">
          TERMO DE CONSENTIMENTO PARA TRATAMENTO DE DADOS PESSOAIS
        </p>

        <p style="margin-bottom: 2.9rem;margin-top: 2.5rem; text-align: justify;">
          Em decorrência da Lei n. 13.709/2018 (Lei Geral de Proteção de Dados ou “LGPD”), que tem como objetivo fortalecer a proteção e privacidade de dados pessoais(como nome, CPF, endereço, etc.) e reforçar a proteção aos dados de saúde (dados sensíveis), solicitamos, através deste Termo, o seu consentimento para armazená-los, utilizá-los e, eventualmente, compartilhá-los com toda segurança e privacidade em software de Prontuário Eletrônico e atendimento, considerando a legislação e as normas técnicas aplicáveis ao caso junto das medidas de segurança aptas a proteger os dados pessoais. O presente Termo se aplicará para hipóteses em que o PACIENTE referenciado é criança ou adolescente, sendo regularmente representado por pelo menos um dos pais ou responsável legal, bem como para casos em que o PACIENTE é maior de 18 (dezoito) anos.
        </p>

        <p style="padding-bottom: 2.9rem; text-align: justify;"><b> PACIENTE (Titular de dados pessoais) </b></p>

        <p style="padding-bottom: 2.9rem; text-align: justify;"><b> Nome completo: {{nome_paciente}}</b></p>

        <p style="padding-bottom: 2.9rem; text-align: justify;"><b> CPF nº {{cpf_paciente}} </b></p>

        <hr>

        <p style="padding-bottom: 2.9rem; padding-top: 2.5rem;">
          Os dados pessoais tratados serão os dados de cadastro e identificação do(a) {{nome_paciente}}&nbsp;(nome, data de nascimento, sexo, e-mail, celular, endereço, CPF, dados do plano de saúde, entre outros opcionais) na plataforma de gestão de atendimento médico Nosso dr, bem como os dados de exames médicos pertinentes, prontuários e da anamnese do(a) {{nome_paciente}}&nbsp;realizada pelo(a){{nome_clinica}}. </p>

        <p style="padding-bottom: 2.9rem; text-align: justify;">
          Os dados pessoais serão utilizados, única e exclusivamente, para possibilitar aprestação de serviço assistencial pelo(a) {{nome_clinica}} com o apoio de ferramentas visando otimizar o atendimento e as prescrições em sistema de Prontuário Eletrônico e atendimento (Nosso dr), bem como para eventual compartilhamento pelo(a) {{nome_clinica}} dos dados pessoais e de saúde referentes à prescrição de medicamentos, com empresas farmacêuticas, objetivando o regular atendimento à saúde do {{nome_paciente}}.
        </p>

        <p style="padding-bottom: 2.9rem; text-align: justify;">
          Também, quando necessário ou pertinente, poderá ocorrer o compartilhamentopelo(a) {{nome_clinica}} dos dados pessoais (identificação) e de saúde referentes ao prontuário médico e exames do(a) {{nome_paciente}}&nbsp;com outros profissionais da área da saúde sujeitos ao sigilo profissional, através do sistema Nosso dr, visando a regular prestação de serviço de tutela da saúde.
        </p>

        <p style="padding-bottom: 2.9rem; ">
          Informamos que seus dados também poderão ser armazenados e utilizados para o atendimento de obrigações legais ou regulatórias que o(a) {{nome_clinica}} e parceiros tenham que cumprir - tais como as imposições do Código de Ética Médica -, bem como para exercício regular de direitos, nos moldes dispostos na Lei Geral de Proteção de Dados. Os dados, eventualmente, poderão ser utilizados para aprimoramento dos serviços ou levantamentos estatísticos, de forma anonimizada nos moldes do art. 5, III eXI da LGPD. Ao preencher o presente Termo e assiná-lo, declaro que tenho ciência e concordoem fornecer o consentimento para o uso de meus dados pessoais ou da criança ou adolescente a que represento, sensíveis ou não, para as finalidades dispostas acima.
        </p>

        <p style="padding-bottom: 2.9rem; text-align: justify;">
          O(A) {{nome_paciente}}&nbsp;(titular de dados), poderá, a qualquer momento, exercer seus direitos previstos na legislação, tais como o acesso aos dados, retificação, eliminação, revogação do consentimento fornecido para o tratamento dedados, entre outros dispostos nos arts. 17 ao 20 da Lei n.13.709/2018. Caso queira exercer algum dos direitos ou para obter mais informações, poderá entrar em contato através do e-mail suporte@nossodr.app ou junto ao profissional para análise eadoção de providências.
        </p>

        <p style="padding-bottom: 2.9rem; text-align: justify;">
          Por fim, declaro ser maior de 18 (dezoito) anos, respondendo de maneira exclusiva pela veracidade das informações prestadas no presente Termo.
        </p>

        <p style="padding-bottom: 2.9rem; text-align: justify;">
          Para maiores detalhes acerca do tratamento de dados pessoais frente ao uso da plataforma Nosso Dr, basta acessar a Política de Privacidade (https://nossorp/politica-de-privacidade.html).
        </p>

        <p style="text-align: center; text-indent: 0; text-align: center;padding-bottom: 2rem;">
          {{municipio}} / {{uf}}, {{dia}} de {{mes}} de {{ano}}.
        </p>

        <div style="text-align: center; text-indent: 0; text-align: center;">
          <p>
            __________________________________________
          </p>
          <p>
            <b> PACIENTE OU REPRESENTANTE LEGAL </b>
          </p>
        </div>
      </div>
    </div>
  </div>
  `;
  }
}
