import { Component, ElementRef, Input, ViewChild } from '@angular/core';
import { Cliente } from 'src/app/nosso-dr/views/cadastros/cliente/cliente.model';
import { ClasseBase } from '../../model/classe-base.model';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Util } from '../../util.model';
import { UsuarioService } from '../../services/usuario.service';

@Component({
  selector: 'app-btn-cliente',
  template: `
    <button
      [disabled]="disabled"
      type="button"
      class="btn btn-icon-text btn-light"
      (click)="showModal()"
    >
      <app-icone [name]="'pessoa'"></app-icone> {{ nome }}
      <ng-container *ngIf="idade">
        , &nbsp;
        <b>{{ idade }} anos</b>
      </ng-container>
    </button>
    <!-- caso vc chame em outro componente e dê erro nas mascaras(mask), é só declarar
        no módulo.
        obs: esse componente não esta mais declarado no shared, para que não dê erro
        nas mascaras precisa declarar no módulo do componente que vc quer utiliza-lo -->

    <ng-template #modalPrincipal let-modal>
      <form>
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Cliente</h5>
          <button
            type="button"
            class="btn-close"
            (click)="modal.close('')"
            aria-label="Close"
          ></button>
        </div>
        <div>
          <ul ngbNav #defaultNav="ngbNav" class="nav-tabs">
            <li [ngbNavItem]="1">
              <ng-template ngbNavContent>
                <div class="card-body">
                  <h5>Dados Paciente</h5>
                  <hr />
                  <div class="row">
                    <div class="col-md-3">
                      <div class="mb-3">
                        <label class="form-label">CPF</label>
                        <p class="inputImprovisado">
                          {{ cliente.cpf_cnpj | mask : "CPF_CNPJ" }}
                        </p>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="mb-3">
                        <label class="form-label">Nome completo</label>
                        <p class="inputImprovisado">{{ cliente.razao }}</p>
                      </div>
                    </div>
                    <div class="col-md-3">
                      <div class="mb-3">
                        <label class="form-label">Data de nascimento</label>
                        <p class="inputImprovisado">
                          {{ cliente._data_nascimento | mask : "00/00/0000" }}
                        </p>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-3">
                      <div class="mb-3">
                        <label class="form-label">Sexo</label>
                        <ng-select
                          name="sexo"
                          bindLabel="descricao"
                          [items]="tipos_sexo"
                          bindValue="value_string"
                          placeholder="Selecione o sexo"
                          [(ngModel)]="cliente.sexo"
                          [readonly]="true"
                        >
                          <ng-template ng-label-tmp let-item="item">
                            <app-icone [name]="item.icone"></app-icone>
                            {{ item.descricao }}
                          </ng-template>
                          <ng-template ng-option-tmp let-item="item">
                            <app-icone [name]="item.icone"></app-icone>
                            {{ item.descricao }}
                          </ng-template>
                        </ng-select>
                      </div>
                    </div>

                    <div class="col-md-6">
                      <div class="mb-3">
                        <label class="form-label">E-mail</label>
                        <p class="inputImprovisado">{{ cliente.email }}</p>
                      </div>
                    </div>
                    <div class="col-md-3">
                      <div class="mb-3">
                        <label class="form-label">Telefone whatsapp</label>
                        <p class="inputImprovisado">
                          {{ cliente.telefone_whatsapp | mask : "(00) 00000-0000" }}
                        </p>
                      </div>
                    </div>

                    <div class="col-md-3">
                      <div class="mb-3">
                        <label class="form-label">Cartão Nacional de Saúde</label>
                        <p class="inputImprovisado">N° {{ cliente.cns }}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </ng-template>
            </li>
          </ul>
          <div [ngbNavOutlet]="defaultNav" class="border border-top-0 p-3"></div>
        </div>
      </form>
    </ng-template>
  `,
  styles: [
    `
      .inputImprovisado {
        border: 1px solid rgb(224, 219, 219);
        border-radius: 5px;
        padding: 7px;
        height: 38px;
      }

      #alinha {
        border: 1px solid rgb(224, 219, 219);
        border-radius: 5px;
        padding: 7px;
        height: 38px;
      }
    `,
  ],
})
export class BtnClienteComponent extends ClasseBase {
  @ViewChild('modalPrincipal', { static: true }) modalPrincipal: ElementRef;
  @Input() disabled: boolean = false;
  @Input() nome: string;
  @Input() idade?: number;
  @Input() id: number;
  tipos_sexo = Util.GetTiposSexo();
  cliente = new Cliente();
  clicouAbriu: boolean;
  constructor(private usuarioSrv: UsuarioService, private modal: NgbModal) {
    super();
  }

  showModal() {
    this.clicouAbriu = true;
    this.usuarioSrv.getCliente(this.id).subscribe((retorno) => {
      if (retorno.success) {
        this.cliente = retorno.retorno;
      } else {
        this.Error(retorno.message);
      }
    });
    this.modal.open(this.modalPrincipal, { size: 'xl', centered: true });
  }
}
