import { Component, Input, Output, EventEmitter } from '@angular/core';
import { ClasseBase } from '../../model/classe-base.model';

@Component({
  selector: 'app-btn-submit',
  template: ` <button
    [disabled]="disabled"
    type="submit"
    class="btn btn-icon-text btn-primary btn-sm"
  >
    <app-icone [name]="'save'"></app-icone> Salvar
  </button>`,
})
export class BtnSubmitComponent {
  @Input() disabled: boolean = false;
  constructor() {}
}
