import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { ModeloHtmlPronto } from '../../views/atendimento/modelo-html-pronto.model';
import { RetornoAPIGenerico } from '../model/retorno-api.model';

@Injectable({
  providedIn: 'root',
})
export class ModelosService {
  constructor(private http: HttpClient) {}
  setModeloPersonalizados(
    modelo: ModeloHtmlPronto
  ): Observable<RetornoAPIGenerico> {
    return this.http.post<RetornoAPIGenerico>(
      `${environment.url_api}/modelos/modelos-personalizados`,
      modelo
    );
  }

  getAllModelosHtmlPronto(modelo: number): Observable<RetornoAPIGenerico> {
    let url = `${environment.url_api}/modelos/modelos-prontos/all?modelo=${modelo}`;
    return this.http.get<RetornoAPIGenerico>(url);
  }

  getModeloHtmlPronto(id: number): Observable<RetornoAPIGenerico> {
    let url = `${environment.url_api}/modelos/modelos-prontos/get?id=${id}`;
    return this.http.get<RetornoAPIGenerico>(url);
  }
}
