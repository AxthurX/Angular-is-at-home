import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { RetornoAPIGenerico } from '../model/retorno-api.model';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ProntuarioService {
  replace: string;
  novo_id: string;
  constructor(private http: HttpClient) { }

  getProntuario(id: number): Observable<RetornoAPIGenerico> {
    return this.http.get<RetornoAPIGenerico>(`${environment.url_api}/prontuario/${id}`);
  }

  getProntuarioUnico(id: number): Observable<RetornoAPIGenerico> {
    return this.http.get<RetornoAPIGenerico>(`${environment.url_api}/prontuario/unico/${id}`);
  }

  replicarAtendimento(id: number): Observable<RetornoAPIGenerico> {
    return this.http.get<RetornoAPIGenerico>(`${environment.url_api}/prontuario/replicar/${id}`);
  }

  detalheTermoLgpd(cod: string): Observable<RetornoAPIGenerico> {
    return this.http.get<RetornoAPIGenerico>(`${environment.url_api}/prontuario/detalhes-lgpd?cod=${cod}`);
  }

  confirmarTermoLgpd(cod: string): Observable<RetornoAPIGenerico> {
    return this.http.post<RetornoAPIGenerico>(`${environment.url_api}/prontuario/confirmar-lgpd`, {
      cod,
    });
  }

  confirmarTermoConsentimento(id: number): Observable<RetornoAPIGenerico> {
    return this.http.post<RetornoAPIGenerico>(`${environment.url_api}/prontuario/confirmar-termo/${id}`, {
      id,
    });
  }

  detalheTermoConsentimento(id: number): Observable<RetornoAPIGenerico> {
    return this.http.get<RetornoAPIGenerico>(`${environment.url_api}/prontuario/detalhes-termo/${id}`);
  }

  enviarEmail(id: number, url: string, nome: string): Observable<RetornoAPIGenerico> {
    return this.http.post<RetornoAPIGenerico>(`${environment.url_api}/prontuario/email/${id}`, {
      id,
      url,
      nome
    });
  }

  enviarEmailLGPD(id: number, id_agendamento: number): Observable<RetornoAPIGenerico> {
    let id_aleatorio = Math.floor(Math.random() * (5000 - 100 + 1)) + 100;
    if (id_agendamento) {
      let id_soma = id_aleatorio + id_agendamento;
      this.replace = [id_aleatorio.toString(), id_agendamento.toString(),id_soma.toString()].join('-')
      this.novo_id = "abc12345#$*%".replace(/([^\d]*)(\d*)([^\w]*)/, this.replace);
    }
    const url = `http://localhost:4200/confirmacao-lgpd/${this.novo_id}`
    return this.http.post<RetornoAPIGenerico>(`${environment.url_api}/prontuario/email-lgpd/${id}`, {
      id,
      url
    });
  }
}
