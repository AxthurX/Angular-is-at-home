import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/compat/firestore';

@Injectable({
  providedIn: 'root',
})
export class FirebaseService {
  constructor(private afs: AngularFirestore) {}

  setHtmlImpressao(id: string, html: string) {
    return this.afs.collection('auxiliar/impressoes/html_mobile').doc(id).set({
      html,
    });
  }

  createId() {
    return this.afs.createId();
  }
}
