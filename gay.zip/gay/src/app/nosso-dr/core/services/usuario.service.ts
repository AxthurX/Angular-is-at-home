import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { RetornoAPIGenerico } from '../model/retorno-api.model';
import { AuthService } from './auth.service';
import { Conselho, Email } from '../../views/configuracao/configuracao.model';

@Injectable({
  providedIn: 'root',
})
export class UsuarioService {
  replace: string;
  novo_id: string;
  constructor(private http: HttpClient, private auth: AuthService) {}

  getCliente(id_cliente: number): Observable<RetornoAPIGenerico> {
    return this.http.get<RetornoAPIGenerico>(
      `${environment.url_api}/cliente/dadosCliente?id_cliente=${id_cliente}`
    );
  }

  atualizarHabilitacaoWhatsAppMedico(
    habilitar_integracao_whatsapp_nosso_dr: boolean
  ): Observable<RetornoAPIGenerico> {
    let id = this.auth.getMedicoSelecionado().id_usuario;
    let url = `${environment.url_api}/usuario/AtualizarHabilitarWhats`;
    return this.http.post<RetornoAPIGenerico>(url, {
      id,
      valor: habilitar_integracao_whatsapp_nosso_dr,
    });
  }

  atualizarInformacaoConselho(
    conselho: Conselho
  ): Observable<RetornoAPIGenerico> {
    return this.http.post<RetornoAPIGenerico>(
      `${environment.url_api}/usuario/InformacaoConselho`,
      conselho
    );
  }

  atualizarInformacaoEmail(email: Email): Observable<RetornoAPIGenerico> {
    return this.http.post<RetornoAPIGenerico>(
      `${environment.url_api}/usuario/InformacaoEmail`,
      email
    );
  }
}
