import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  keyToken: string = 'nossodr:token';
  keyLogin: string = 'nossodr:login';
  keyDadosColaborador: string = 'nossodr:colaborador';
  keyDadosEmpresa: string = 'nossodr:empresa';
  keyDadosMedico: string = 'nossodr:medico';
  keyDadosAtendente: string = 'nossodr:atendente';

  constructor(private router: Router, private http: HttpClient) {}

  get isAuthenticated(): Promise<boolean> {
    return new Promise((resolve) => {
      const token = this.getToken();
      if (token) {
        return resolve(true);
      }
      return resolve(false);
    });
  }

  setToken(
    token: string,
    dados_colaborador: DadosColaborador,
    dados_empresa: DadosEmpresa,
    medico: Medico,
    atendente: Atendente
  ) {
    localStorage.setItem(this.keyToken, token);
    localStorage.setItem(
      this.keyDadosColaborador,
      JSON.stringify(dados_colaborador)
    );
    this.setDadosEmpresa(dados_empresa);
    localStorage.setItem(this.keyDadosMedico, JSON.stringify(medico));
    localStorage.setItem(this.keyDadosAtendente, JSON.stringify(atendente));
  }

  setDadosEmpresa(dados_empresa: DadosEmpresa) {
    localStorage.setItem(this.keyDadosEmpresa, JSON.stringify(dados_empresa));
  }

  setDadosMedico(medico: Medico) {
    localStorage.setItem(this.keyDadosMedico, JSON.stringify(medico));
  }

  setLogin(login: LoginResponse) {
    localStorage.setItem(this.keyLogin, JSON.stringify(login));
  }

  getToken() {
    return localStorage.getItem(this.keyToken);
  }

  getColaboradorLogado(): DadosColaborador {
    return JSON.parse(
      localStorage.getItem(this.keyDadosColaborador)?.toString() ?? ''
    );
  }

  getEmpresaLogada(): DadosEmpresa {
    return JSON.parse(
      localStorage.getItem(this.keyDadosEmpresa)?.toString() ?? ''
    );
  }

  getMedicoSelecionado(): Medico {
    return JSON.parse(
      localStorage.getItem(this.keyDadosMedico)?.toString() ?? ''
    );
  }

  getAtendenteSelecionado(): Atendente {
    return JSON.parse(
      localStorage.getItem(this.keyDadosAtendente)?.toString() ?? ''
    );
  }

  getLogin(): LoginResponse {
    return JSON.parse(localStorage.getItem(this.keyLogin)?.toString() ?? '');
  }

  logout() {
    localStorage.removeItem(this.keyToken);
    localStorage.removeItem(this.keyLogin);
    localStorage.removeItem(this.keyDadosColaborador);
    this.router.navigateByUrl('/auth/login');
  }

  getUsuario(login: string, senha: string): Observable<any> {
    return this.http.post<any>(`${environment.url_api}/autoriza/login`, {
      login,
      senha,
      is_nossodr: true,
    });
  }
}

export class LoginRequest {
  login_online: string;
  senha_online: string;
}

export class LoginResponse {
  authenticated: boolean;
  token: string;
  message: string;
  dados_colaborador: DadosColaborador;
  dados_empresa: DadosEmpresa;
  atendente: Atendente;
  medicos: Medico[];
}

export class DadosColaborador {
  nome: string;
  id_colaborador: number;
  id_usuario: number;
  tipo_usuario_nosso_dr: number;
}

export class Medico {
  id_usuario: number;
  nome: string;
  email: string;
  id_uf_conselho: number;
  sigla_conselho: string;
  numero_conselho: string;
  rqe: string;
  endereco_email: string;
  senha_email: string;
  exibicao_email: string;
  porta: string;
  smtp: string;
  email_copia_oculta: string;
  ssl: boolean;
  assinatura: string;
}

export class Atendente {
  id_usuario: number;
  nome: string;
  email: string;
  todos: true;
}

export class DadosEmpresa {
  razao: string;
  fantasia: string;
  cpf_cnpj: string;
  cpf_cnpj_formatado: string;
  nome_colaborador: string;
  email: string;
  id: number;
  id_empresa_acessar: number;
  id_colaborador: number;
  id_usuario: number;
  id_banco_dados: number;
  habilitar_integracao_whatsapp_nosso_dr: boolean;
}
