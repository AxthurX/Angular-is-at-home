import { Injectable } from '@angular/core';
import { AuthService } from './auth.service';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { RetornoAPIGenerico } from '../model/retorno-api.model';
import { environment } from 'src/environments/environment';
import { Colaborador } from '../../views/cadastros/colaborador/colaborador.model';

@Injectable({
  providedIn: 'root',
})
export class ColaboradorService {
  constructor(private http: HttpClient, private auth: AuthService) {}

  getColaborador(id_colaborador: number): Observable<RetornoAPIGenerico> {
    return this.http.get<RetornoAPIGenerico>(`${environment.url_api}/colaborador/dadosColaborador?id_colaborador=${id_colaborador}`);
  }

  pesquisar(texto: string): Observable<RetornoAPIGenerico> {
    return this.http.get<RetornoAPIGenerico>(
      `${environment.url_api}/colaborador/pesquisar?texto=${texto}`
    );
  }

  salvar(colaborador: Colaborador): Observable<RetornoAPIGenerico> {
    return this.http.post<RetornoAPIGenerico>(`${environment.url_api}/colaborador`,
      [colaborador]
    );
  }
}
