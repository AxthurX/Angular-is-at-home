import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { RetornoAPIGenerico } from '../model/retorno-api.model';
import {
  Cbos,
  Cobranca,
  Compatibilidade,
  Composicao,
  DemaisDados,
  Diagnosticos,
  Incompatibilidade,
  Procedimento,
} from '../../views/cadastros/procedimento/procedimento.model';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class ProcedimentoService {
  constructor(private http: HttpClient) {}

  salvarProcedimento(procedimento: Procedimento): Observable<RetornoAPIGenerico> {
    return this.http.post<RetornoAPIGenerico>(`${environment.url_api}/procedimento`,
      procedimento
    );
  }

  salvarDemaisDados(demais_dados_procedimento: DemaisDados): Observable<RetornoAPIGenerico> {
    return this.http.post<RetornoAPIGenerico>(
      `${environment.url_api}/procedimento/demais-dados`,
      demais_dados_procedimento
    );
  }

  salvarCobranca(cobranca: Cobranca): Observable<RetornoAPIGenerico> {
    return this.http.post<RetornoAPIGenerico>(
      `${environment.url_api}/procedimento/cobranca`,
      cobranca
    );
  }

  getCobranca(id_colaborador: number): Observable<RetornoAPIGenerico> {
    return this.http.get<RetornoAPIGenerico>(
      `${environment.url_api}/procedimento/cobranca/all?id_colaborador=${id_colaborador}`
    );
  }

  salvarComposicao(composicao: Composicao): Observable<RetornoAPIGenerico> {
    return this.http.post<RetornoAPIGenerico>(
      `${environment.url_api}/procedimento/composicao`,
      composicao
    );
  }

  salvarDiagnosticos(diagnosticos: Diagnosticos): Observable<RetornoAPIGenerico> {
    return this.http.post<RetornoAPIGenerico>(
      `${environment.url_api}/procedimento/diagnosticos`,
      diagnosticos
    );
  }

  getDiagnosticos(id_colaborador: number): Observable<RetornoAPIGenerico> {
    return this.http.get<RetornoAPIGenerico>(
      `${environment.url_api}/procedimento/diagnosticos/all?id_colaborador=${id_colaborador}`
    );
  }

  salvarCompatibilidade(compatibilidade: Compatibilidade): Observable<RetornoAPIGenerico> {
    return this.http.post<RetornoAPIGenerico>(
      `${environment.url_api}/procedimento/compatibilidade`,
      compatibilidade
    );
  }

  getCompatibilidade(id_colaborador: number): Observable<RetornoAPIGenerico> {
    return this.http.get<RetornoAPIGenerico>(
      `${environment.url_api}/procedimento/compatibilidade/all?id_colaborador=${id_colaborador}`
    );
  }

  salvarIncompatibilidade(incompatibilidade: Incompatibilidade): Observable<RetornoAPIGenerico> {
    return this.http.post<RetornoAPIGenerico>(
      `${environment.url_api}/procedimento/incompatibilidade`,
      incompatibilidade
    );
  }

  getIncompatibilidade(id_colaborador: number): Observable<RetornoAPIGenerico> {
    return this.http.get<RetornoAPIGenerico>(
      `${environment.url_api}/procedimento/incompatibilidade/all?id_colaborador=${id_colaborador}`
    );
  }

  salvarCbos(cbos: Cbos): Observable<RetornoAPIGenerico> {
    return this.http.post<RetornoAPIGenerico>(
      `${environment.url_api}/procedimento/cbos`,
      cbos
    );
  }

  getCbos(id_colaborador: number): Observable<RetornoAPIGenerico> {
    return this.http.get<RetornoAPIGenerico>(
      `${environment.url_api}/procedimento/cbos/all?id_colaborador=${id_colaborador}`
    );
  }
}
