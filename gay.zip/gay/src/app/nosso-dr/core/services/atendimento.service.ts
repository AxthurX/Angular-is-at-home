import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { RetornoAPIGenerico } from '../model/retorno-api.model';
import { environment } from 'src/environments/environment';
import { Util } from '../util.model';
import { Atendimento } from '../../views/atendimento/atendimento.model';

@Injectable({
  providedIn: 'root',
})
export class AtendimentoService {
  constructor(private http: HttpClient) {}

  getAtendimentos(
    id_medico: number,
    id_empresa: number,
    data_inicial: Date,
    data_final: Date
  ): Observable<RetornoAPIGenerico> {
    let url = `${
      environment.url_api
    }/atendimento/all?id_usuario=${id_medico}&id_empresa=${id_empresa}&data_inicial=${Util.GetDataFormatada(
      data_inicial,
      'yyyy-MM-dd'
    )}&data_final=${Util.GetDataFormatada(data_final, 'yyyy-MM-dd')}`;
    return this.http.get<RetornoAPIGenerico>(url);
  }

  getAtendimentosById(id: number): Observable<RetornoAPIGenerico> {
    return this.http.get<RetornoAPIGenerico>(`${environment.url_api}/atendimento/${id}`);
  }

  setAtendimento(atendimento: Atendimento): Observable<RetornoAPIGenerico> {
    return this.http.post<RetornoAPIGenerico>(
      `${environment.url_api}/atendimento`,
      atendimento
    );
  }
}
