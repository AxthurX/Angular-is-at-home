import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
//import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Cliente } from '../../views/cadastros/cliente/cliente.model';
import { RetornoAPIGenerico } from '../model/retorno-api.model';

@Injectable({
  providedIn: 'root',
})
export class ClienteService {
  constructor(private http: HttpClient) {}

  salvar(cliente: Cliente): Observable<RetornoAPIGenerico> {
    return this.http.post<RetornoAPIGenerico>(`${environment.url_api}/cliente`,
      [cliente]
    );
  }

  salvarBairro(id_municipio: number, descricao: string): Observable<RetornoAPIGenerico>{
    return this.http.post<RetornoAPIGenerico>(`${environment.url_api}/bairro/salvar`,
    {
      id_municipio,
      descricao
    })
  }

  getBairro(id_municipio: Number): Observable<RetornoAPIGenerico> {
    let url = `${environment.url_api}/enderecos/bairros?id_municipios=${id_municipio}`;
     return this.http.get<RetornoAPIGenerico>(url);
  }

 getMunicipio(id_uf: number): Observable<RetornoAPIGenerico> {
   let url = `${environment.url_api}/enderecos/municipios?id_uf=${id_uf}`;
    return this.http.get<RetornoAPIGenerico>(url);
  }


  getUf(): Observable<RetornoAPIGenerico> {
    return this.http.get<RetornoAPIGenerico>(`${environment.url_api}/enderecos/ufs`);
  }

  pesquisar(texto: string): Observable<RetornoAPIGenerico> {
    return this.http.get<RetornoAPIGenerico>(
      `${environment.url_api}/cliente/pesquisar?texto=${texto}`
    );
  }

  consultaCEP(cep: string): Observable<RetornoEndereco> {
    cep = cep.replace('-', '');
    return this.http.get<RetornoEndereco>(
      `https://viacep.com.br/ws/${cep}/json`
    );
  }
}

export class RetornoEndereco {
  cep: string;
  logradouro: string;
  complemento: string;
  bairro: string;
  localidade: string;
  uf: string;
  ibge: string;
  gia: string;
  ddd: string;
  siafi: string;
  //auxiliar
  erro: boolean;
}


