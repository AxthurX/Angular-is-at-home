import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { RetornoAPIGenerico } from '../model/retorno-api.model';
import { Categorias, Credenciados, DemaisDados, Discriminativo, Faturamento, PorteMatMed, PortePrc, Convenio } from '../../views/cadastros/convenio/convenio.model';

@Injectable({
  providedIn: 'root',
})
export class ConvenioService {
  constructor(private http: HttpClient) {}

  salvarConvenio(convenio: Convenio): Observable<RetornoAPIGenerico> {
    return this.http.post<RetornoAPIGenerico>(
      `${environment.url_api}/convenio`,
      convenio
    );
  }

  salvarDemaisDados(
    demais_dados_convenio: DemaisDados
  ): Observable<RetornoAPIGenerico> {
    return this.http.post<RetornoAPIGenerico>(
      `${environment.url_api}/convenio/demais-dados`,
      demais_dados_convenio
    );
  }

  salvarPorteMatMed(matmed: PorteMatMed): Observable<RetornoAPIGenerico> {
    return this.http.post<RetornoAPIGenerico>(
      `${environment.url_api}/convenio/porte-matmed`,
      matmed
    );
  }

  getPorteMatMed(id_colaborador: number): Observable<RetornoAPIGenerico> {
    return this.http.get<RetornoAPIGenerico>(
      `${environment.url_api}/convenio/porte-matmed/all?id_colaborador=${id_colaborador}`
    );
  }

  salvarPortePrc(prc: PortePrc): Observable<RetornoAPIGenerico> {
    return this.http.post<RetornoAPIGenerico>(
      `${environment.url_api}/convenio/porte-prc`,
      prc
    );
  }

  getPortePrc(id_colaborador: number): Observable<RetornoAPIGenerico> {
    return this.http.get<RetornoAPIGenerico>(
      `${environment.url_api}/convenio/porte-prc/all?id_colaborador=${id_colaborador}`
    );
  }

  salvarCredenciados(
    credenciados: Credenciados
  ): Observable<RetornoAPIGenerico> {
    return this.http.post<RetornoAPIGenerico>(
      `${environment.url_api}/convenio/credenciados`,
      credenciados
    );
  }

  getCredenciados(id_colaborador: number): Observable<RetornoAPIGenerico> {
    return this.http.get<RetornoAPIGenerico>(
      `${environment.url_api}/convenio/credenciados/all?id_colaborador=${id_colaborador}`
    );
  }

  salvarCategorias(categoria: Categorias): Observable<RetornoAPIGenerico> {
    return this.http.post<RetornoAPIGenerico>(
      `${environment.url_api}/convenio/categorias`,
      categoria
    );
  }

  getCategorias(id_colaborador: number): Observable<RetornoAPIGenerico> {
    return this.http.get<RetornoAPIGenerico>(
      `${environment.url_api}/convenio/categorias/all?id_colaborador=${id_colaborador}`
    );
  }

  salvarDiscriminativo(
    discriminativo: Discriminativo
  ): Observable<RetornoAPIGenerico> {
    return this.http.post<RetornoAPIGenerico>(
      `${environment.url_api}/convenio/discriminativo`,
      discriminativo
    );
  }

  salvarFaturamento(faturamento: Faturamento): Observable<RetornoAPIGenerico> {
    return this.http.post<RetornoAPIGenerico>(
      `${environment.url_api}/convenio/faturamento`,
      faturamento
    );
  }

  pesquisarPrc(
    convenio: string,
    categoria: string,
    prestador: string
  ): Observable<RetornoAPIGenerico> {
    return this.http.get<RetornoAPIGenerico>(
      `${environment.url_api}/convenio/pesquisarPrc?convenio=${convenio}&categoria=${categoria}&prestador=${prestador}`
    );
  }

  pesquisarMatMed(
    convenio: string,
    categoria: string,
    familia: string,
    subgrupo_familia: string
  ): Observable<RetornoAPIGenerico> {
    return this.http.get<RetornoAPIGenerico>(
      `${environment.url_api}/convenio/pesquisarMatMed?convenio=${convenio}&categoria=${categoria}&familia=${familia}&subgrupo_familia=${subgrupo_familia}`
    );
  }
}
