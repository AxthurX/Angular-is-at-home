import { Injectable } from '@angular/core';
import { Agendamento } from '../../views/agenda/agendamento.model';
import { RetornoAPIGenerico } from '../model/retorno-api.model';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { Util } from '../util.model';

@Injectable({
  providedIn: 'root',
})
export class AgendamentoService {
  constructor(private http: HttpClient) {}

  setAgendamento(agendamento: Agendamento): Observable<RetornoAPIGenerico> {
    return this.http.post<RetornoAPIGenerico>(
      `${environment.url_api}/agendamento`,
      agendamento
    );
  }

  getAgendamentos(
    id_medico: number,
    id_empresa: number,
    data_inicial: Date,
    data_final: Date,
    status?: number
  ): Observable<RetornoAPIGenerico> {
    let url = `${
      environment.url_api
    }/agendamento/all?id_usuario=${id_medico}&id_empresa=${id_empresa}&data_inicial=${Util.GetDataFormatada(
      data_inicial,
      'yyyy-MM-dd'
    )}&data_final=${Util.GetDataFormatada(data_final, 'yyyy-MM-dd')}`;
    if (status) {
      url += `&status=${status}`;
    }
    return this.http.get<RetornoAPIGenerico>(url);
  }

  confirmarAgendamento(cod: string): Observable<RetornoAPIGenerico> {
    return this.http.post<RetornoAPIGenerico>(`${environment.url_api}/agendamento/confirmar`,
      {
        cod,
      }
    );
  }

  detalheAgendamento(cod: string): Observable<RetornoAPIGenerico> {
    let url = `${environment.url_api}/agendamento/detalhes?cod=${cod}`;
    return this.http.get<RetornoAPIGenerico>(url);
  }

  getAgendamentosCancelados(id: number): Observable<RetornoAPIGenerico> {
    return this.http.get<RetornoAPIGenerico>(
      `${environment.url_api}/agendamento/cancelados/${id}`
    );
  }

  getAgendamentosNaoConfirmados(id: number): Observable<RetornoAPIGenerico> {
    return this.http.get<RetornoAPIGenerico>(
      `${environment.url_api}/agendamento/nao-confirmados/${id}`
    );
  }
}
