import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import {
  RetornoApiWhatsQrCode,
  RetornoBaseApiWhats,
} from '../model/retorno-api.model';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root',
})
export class WhatsAppService {
  key: string;
  constructor(private http: HttpClient, private auth: AuthService) {
    this.atualizarKey();
  }

  atualizarKey() {
    //a key vou usar o id do medico
    this.key = this.auth.getMedicoSelecionado().id_usuario.toString();
  }

  iniciarInstancia(): Observable<RetornoBaseApiWhats> {
    return this.http.get<RetornoBaseApiWhats>(
      `${environment.url_api_zap}?action=instance/init&key=${this.key}`
    );
  }

  gerarQrCode(): Observable<RetornoApiWhatsQrCode> {
    return this.http.get<RetornoApiWhatsQrCode>(
      `${environment.url_api_zap}?action=instance/qrbase64&key=${this.key}`
    );
  }

  enviarMensagem(
    numero: string,
    mensagem: string
  ): Observable<RetornoBaseApiWhats> {
    //ta com o digito novo, tiro pq a api n funciona se mandar desse jeito
    if (numero.length === 11) {
      let comeco = numero.substring(0, 2);
      let fim = numero.substring(3);

      numero = comeco + fim;
    }
    numero = '55' + numero;

    return this.http.post<RetornoBaseApiWhats>(
      `${environment.url_api_zap}?action=message/text&key=${this.key}`,
      {
        id: numero,
        message: mensagem,
      }
    );
  }
}
