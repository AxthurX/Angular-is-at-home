import { TipoIcone } from '../components/icone.component';

export class Value {
  id: number;
  descricao: string;
  icone?: TipoIcone;
  value_string?: string;
}
